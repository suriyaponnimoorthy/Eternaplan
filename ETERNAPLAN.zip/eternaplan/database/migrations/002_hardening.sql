ALTER TABLE users MODIFY COLUMN otp_code VARCHAR(64);
ALTER TABLE users ADD COLUMN token_version INT UNSIGNED NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN customer_id INT UNSIGNED NULL;
ALTER TABLE users ADD CONSTRAINT fk_user_customer FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE SET NULL;
CREATE TABLE staff_invitations (
 id CHAR(36) PRIMARY KEY, company_id INT UNSIGNED NOT NULL, email VARCHAR(150) NOT NULL,
 role_name VARCHAR(50) NOT NULL, token_hash CHAR(64) NOT NULL UNIQUE, expires_at DATETIME NOT NULL,
 accepted_at DATETIME NULL, customer_id INT UNSIGNED NULL, vendor_id INT UNSIGNED NULL,
 FOREIGN KEY(company_id) REFERENCES companies(id), FOREIGN KEY(customer_id) REFERENCES customers(id), FOREIGN KEY(vendor_id) REFERENCES vendors(id)
) ENGINE=InnoDB;
CREATE TABLE private_documents (
 id CHAR(36) PRIMARY KEY, company_id INT UNSIGNED NOT NULL, uploaded_by INT UNSIGNED NOT NULL,
 original_name VARCHAR(200) NOT NULL, mime_type VARCHAR(100) NOT NULL, size_bytes INT NOT NULL,
 nonce CHAR(24) NOT NULL, auth_tag CHAR(32) NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(company_id) REFERENCES companies(id), FOREIGN KEY(uploaded_by) REFERENCES users(id)
) ENGINE=InnoDB;
CREATE TABLE billing_orders (
 id CHAR(36) PRIMARY KEY, company_id INT UNSIGNED NOT NULL, invoice_id INT UNSIGNED NOT NULL,
 amount_minor BIGINT UNSIGNED NOT NULL, currency CHAR(3) NOT NULL DEFAULT 'inr',
 request_key VARCHAR(100) NOT NULL, session_id VARCHAR(200) NULL UNIQUE, session_url TEXT NULL,
 payment_intent VARCHAR(200) NULL UNIQUE, state VARCHAR(30) NOT NULL DEFAULT 'created',
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_order_request(company_id,request_key), FOREIGN KEY(invoice_id) REFERENCES invoices(id)
) ENGINE=InnoDB;
CREATE TABLE billing_refunds (
 id CHAR(36) PRIMARY KEY, company_id INT UNSIGNED NOT NULL, order_id CHAR(36) NOT NULL,
 request_key VARCHAR(100) NOT NULL, amount_minor BIGINT UNSIGNED NOT NULL,
 provider_refund_id VARCHAR(200) NULL UNIQUE, state VARCHAR(30) NOT NULL DEFAULT 'created',
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_refund_request(company_id,request_key), FOREIGN KEY(order_id) REFERENCES billing_orders(id)
) ENGINE=InnoDB;
CREATE TABLE billing_webhook_events (
 id VARCHAR(200) PRIMARY KEY, event_type VARCHAR(100) NOT NULL, processed_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE billing_ledger (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, company_id INT UNSIGNED NOT NULL,
 invoice_id INT UNSIGNED NOT NULL, order_id CHAR(36) NULL, provider_ref VARCHAR(200) NOT NULL UNIQUE,
 amount_minor BIGINT NOT NULL, kind VARCHAR(30) NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(invoice_id) REFERENCES invoices(id), FOREIGN KEY(order_id) REFERENCES billing_orders(id),
 INDEX idx_ledger_invoice(invoice_id)
) ENGINE=InnoDB;
ALTER TABLE invoices ADD COLUMN opening_paid_minor BIGINT NOT NULL DEFAULT 0;
UPDATE invoices SET opening_paid_minor=ROUND(amount_paid*100);
CREATE TABLE request_quotas (
 quota_key VARCHAR(180) PRIMARY KEY, hits INT UNSIGNED NOT NULL, expires_at DATETIME NOT NULL
) ENGINE=InnoDB;
CREATE TABLE notification_jobs (
 id CHAR(36) PRIMARY KEY, kind VARCHAR(20) NOT NULL, payload JSON NOT NULL,
 attempts INT NOT NULL DEFAULT 0, state VARCHAR(20) NOT NULL DEFAULT 'pending',
 available_at DATETIME NOT NULL, locked_until DATETIME NULL, lease_token CHAR(36) NULL,
 last_error VARCHAR(200) NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
 INDEX idx_jobs_ready(state,available_at)
) ENGINE=InnoDB;
CREATE INDEX idx_booking_vendor_range ON bookings(vendor_id,booking_date,end_date,status);
CREATE INDEX idx_booking_venue_range ON bookings(venue_id,booking_date,end_date,status);
DROP TRIGGER IF EXISTS tr_payment_after_insert;
ALTER TABLE guests MODIFY COLUMN invitation_code VARCHAR(64);
ALTER TABLE users ADD COLUMN mfa_secret JSON NULL, ADD COLUMN mfa_pending JSON NULL, ADD COLUMN mfa_last_step BIGINT NOT NULL DEFAULT 0;
ALTER TABLE events MODIFY COLUMN event_code VARCHAR(40) NOT NULL;
ALTER TABLE guests MODIFY COLUMN qr_code MEDIUMTEXT;
CREATE TABLE recommendation_feedback (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY, company_id INT UNSIGNED NOT NULL, user_id INT UNSIGNED NOT NULL,
 item_kind VARCHAR(20) NOT NULL, item_id INT UNSIGNED NOT NULL, helpful TINYINT NOT NULL,
 created_at DATETIME DEFAULT CURRENT_TIMESTAMP, INDEX idx_feedback_company(company_id,created_at)
) ENGINE=InnoDB;
ALTER TABLE venues ADD COLUMN city_normalized VARCHAR(100) GENERATED ALWAYS AS (LOWER(TRIM(city))) STORED;
ALTER TABLE vendors ADD COLUMN city_normalized VARCHAR(100) GENERATED ALWAYS AS (LOWER(TRIM(city))) STORED;
CREATE INDEX idx_venue_discovery ON venues(company_id,is_available,city_normalized,capacity_max);
CREATE INDEX idx_vendor_discovery ON vendors(company_id,approval_status,city_normalized,category_id);
UPDATE users SET token_version=token_version+1,refresh_token=NULL;
