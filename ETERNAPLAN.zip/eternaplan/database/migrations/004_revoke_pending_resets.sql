UPDATE users SET password_reset_token=NULL,password_reset_expires=NULL,failed_attempts=0,locked_until=NULL
WHERE password_reset_token IS NOT NULL OR password_reset_expires IS NOT NULL OR failed_attempts<>0 OR locked_until IS NOT NULL;
