ALTER TABLE users ADD COLUMN mfa_pending_expires_at DATETIME NULL, ADD COLUMN mfa_pending_version INT UNSIGNED NULL;
UPDATE users SET mfa_pending=NULL,refresh_token=NULL,token_version=token_version+1;
ALTER TABLE billing_orders ADD COLUMN provider_account_id VARCHAR(200) NULL, ADD COLUMN checkout_payload JSON NULL, ADD COLUMN last_error_code VARCHAR(80) NULL;
ALTER TABLE billing_ledger ADD COLUMN receipt_metadata JSON NULL;
