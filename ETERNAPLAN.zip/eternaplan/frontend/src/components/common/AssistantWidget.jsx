import { useEffect, useRef, useState } from 'react';
import api from '../../services/api';
export default function AssistantWidget() {
  const [open,setOpen]=useState(false), [messages,setMessages]=useState([]), [text,setText]=useState('');
  const [preferences,setPreferences]=useState({});
  const [useAI,setUseAI]=useState(false), [busy,setBusy]=useState(false), [error,setError]=useState('');
  const input=useRef(null), toggle=useRef(null), end=useRef(null);
  useEffect(()=>{if(open) input.current?.focus();},[open]);
  useEffect(()=>{end.current?.scrollIntoView({block:'nearest'});},[messages,busy]);
  useEffect(()=>{const update=e=>{setPreferences(e.detail);};window.addEventListener('eternaplan-preferences',update);return()=>window.removeEventListener('eternaplan-preferences',update);},[]);
  const close=()=>{setOpen(false);toggle.current?.focus();};
  const send=async(e)=>{
    e.preventDefault(); const message=text.trim(); if(!message || busy) return;
    const history=messages.slice(-10).map(({role,content})=>({role,content}));
    setMessages(m=>[...m,{role:'user',content:message}]);setText('');setBusy(true);setError('');
    try {
      const {data}=await api.post('/ai/chat',{message,history,use_ai:useAI,preferences});
      setMessages(m=>[...m,{role:'assistant',content:data.data.reply,notice:data.data.notice,mode:data.data.mode}]);
    } catch {setError('Your message could not be answered. Please try again.');}
    finally {setBusy(false);input.current?.focus();}
  };
  return <div className="fixed bottom-5 right-4 z-40">
    {open && <section aria-label="Event planning assistant" onKeyDown={e=>{if(e.key==='Escape')close();}} className="mb-3 flex flex-col rounded-2xl border shadow-2xl overflow-hidden" style={{width:'min(390px, calc(100vw - 32px))',height:'min(620px, calc(100dvh - 110px))',background:'#0f1628',borderColor:'#9a7a4a'}}>
      <header className="p-4 border-b border-white/10 flex justify-between items-start"><div><h2 className="text-lg" style={{color:'#e8c98a'}}>✦ Planning concierge</h2><p className="text-xs text-gray-300 mt-1">Advice and discovery for your event</p></div><button type="button" onClick={close} aria-label="Close assistant" className="p-2">✕</button></header>
      <div className="p-4 border-b border-white/10 text-xs text-gray-300"><p className="mb-2">{Object.keys(preferences).length ? 'Using your latest AI Discover filters.' : 'Use AI Discover to personalize the supplier shortlist.'}</p><label className="flex items-center gap-2"><input type="checkbox" checked={useAI} disabled={busy} onChange={e=>setUseAI(e.target.checked)}/>Enable conversational AI</label><p className="mt-2">When enabled, this conversation and a limited supplier shortlist are sent to OpenAI. Avoid sharing personal or payment details. Local guidance works without AI.</p></div>
      <div className="overflow-y-auto flex-1 p-4 space-y-4" role="log" aria-live="polite" aria-relevant="additions">
        {!messages.length && <p className="text-sm text-gray-300">Hello! Ask for a planning checklist, budget advice or venue and vendor suggestions. Use AI Discover to filter recommendations.</p>}
        {messages.map((m,i)=><div key={i} className="rounded-xl p-3 text-sm whitespace-pre-wrap break-words" style={{background:m.role==='user'?'#23304a':'#19233e'}}><p className="text-xs mb-1" style={{color:'#e8c98a'}}>{m.role==='user'?'You':m.mode==='ai'?'AI assistant':'Local planning guide'}</p>{m.content}{m.notice && <p className="text-xs text-gray-300 mt-3">{m.notice}</p>}</div>)}
        {busy && <p className="text-sm text-gray-300">Preparing an answer…</p>}<div ref={end}/>
      </div>
      {error && <p role="alert" className="px-4 text-sm text-red-300">{error}</p>}
      <form onSubmit={send} className="p-3 flex gap-2 border-t border-white/10"><label className="sr-only" htmlFor="assistant-message">Your message</label><input id="assistant-message" ref={input} value={text} onChange={e=>setText(e.target.value)} maxLength={2000} className="input-dark" placeholder="Ask about your event…"/><button className="btn-gold" disabled={busy || !text.trim()}>Send</button></form>
      <button type="button" disabled={busy} onClick={()=>{setMessages([]);setError('');}} className="text-xs text-gray-300 pb-3">Clear conversation</button>
    </section>}
    <button ref={toggle} onClick={()=>open?close():setOpen(true)} className="btn-gold float-right" aria-expanded={open}>✦ {open?'Close':'Ask concierge'}</button>
  </div>;
}
