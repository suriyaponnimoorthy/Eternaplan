import {useEffect,useState} from 'react';
import api from '../../services/api';
import {useAuthStore} from '../../store/authStore';

export default function MFASettings(){
 const [enabled,setEnabled]=useState(null),[setup,setSetup]=useState(null);
 const [password,setPassword]=useState(''),[code,setCode]=useState('');
 const [error,setError]=useState(''),[busy,setBusy]=useState(false);
 useEffect(()=>{
  api.get('/mfa').then(r=>setEnabled(r.data.data.enabled))
   .catch(()=>setError('Could not load authenticator status.'));
 },[]);
 const action=enabled?'disable':setup?'enable':'setup';
 const submit=async e=>{
  e.preventDefault();setBusy(true);setError('');
  try{
   const response=await api.post(`/mfa/${action}`,action==='setup'?{password}:{password,code});
   setPassword('');setCode('');
   if(action==='setup')setSetup(response.data.data);
   else{
    await useAuthStore.getState().logout();
    window.location.assign('/login');
   }
  }catch(e){setError(e.response?.data?.message||'Authenticator update failed.');}
  finally{setBusy(false);}
 };
 return <section className="my-6">
  <h2 className="text-xl mb-3">Authenticator verification</h2>
  {enabled!==null&&<>
   <p className="text-gray-300 mb-4">{enabled
    ?'To replace your authenticator, disable it with your password and a fresh code, then sign in to enroll the replacement.'
    :'Add a second sign-in step using your authenticator app.'}</p>
   {setup&&<p className="break-all my-4">Enter this secret in your authenticator app within 10 minutes. <strong>{setup.secret}</strong></p>}
   <form onSubmit={submit}>
    <label>Current password<input className="input-dark my-3 max-w-xs block" type="password" autoComplete="current-password" required value={password} onChange={e=>setPassword(e.target.value)}/></label>
    {action!=='setup'&&<label>{enabled?'Current authenticator code':'New authenticator code'}<input className="input-dark my-3 max-w-xs block" required pattern="[0-9]{6}" inputMode="numeric" autoComplete="one-time-code" value={code} onChange={e=>setCode(e.target.value)}/></label>}
    <button className="btn-gold" disabled={busy}>{enabled?'Disable authenticator':setup?'Enable authenticator':'Set up authenticator'}</button>
    {setup&&<button type="button" className="underline ml-4" disabled={busy} onClick={()=>{setSetup(null);setCode('');setError('');}}>Start setup again</button>}
   </form>
  </>}
  {error&&<p role="alert" className="text-red-300 my-3">{error}</p>}
 </section>;
}
