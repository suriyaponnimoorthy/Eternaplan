export { InvoiceDetailPage as default } from '../WorkspacePages';
