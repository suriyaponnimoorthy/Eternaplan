export { ExpensesPage as default } from '../WorkspacePages';
