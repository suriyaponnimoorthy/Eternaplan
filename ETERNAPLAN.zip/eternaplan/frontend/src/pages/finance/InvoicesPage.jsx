export { InvoicesPage as default } from '../WorkspacePages';
