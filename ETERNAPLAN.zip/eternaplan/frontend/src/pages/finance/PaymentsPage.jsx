export { PaymentsPage as default } from '../WorkspacePages';
