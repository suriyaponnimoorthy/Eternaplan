import { useEffect, useState } from 'react';
import api from '../services/api';
import { Link } from 'react-router-dom';
export default function DiscoverPage() {
  const [form,setForm] = useState({city:'',guests:'',budget:'',date:''});
  const [results,setResults] = useState(null), [busy,setBusy] = useState(false), [error,setError] = useState('');
  const [categories,setCategories]=useState([]);
  useEffect(()=>{api.get('/meta/vendor-categories').then(({data})=>setCategories(data.data)).catch(()=>{});},[]);
  const change = e => setForm({...form,[e.target.name]:e.target.value});
  const search = async e => {
    e.preventDefault(); setBusy(true); setError(''); setResults(null);
    const preferences = Object.fromEntries(Object.entries(form).filter(([,v])=>v!==''));
    try { const {data} = await api.post('/ai/recommendations',{preferences}); setResults(data.data); window.dispatchEvent(new CustomEvent('eternaplan-preferences',{detail:preferences})); }
    catch { setError('Recommendations could not be loaded. Please try again.'); }
    finally { setBusy(false); }
  };
  return <div className="max-w-6xl mx-auto pb-24">
    <p className="text-sm tracking-widest" style={{color:'#c9a96e'}}>ETERNAPLAAN · INTELLIGENT PLANNING</p>
    <h1 className="text-4xl mt-3 mb-3" style={{fontFamily:'Cormorant Garamond,serif'}}>A better match for your occasion.</h1>
    <p className="text-gray-300 mb-7 max-w-2xl">Discover venues and trusted suppliers with clear reasons for every match. Start with what matters to your event.</p>
    <form onSubmit={search} className="card-dark p-5 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <label className="text-sm">City<input className="input-dark mt-2" name="city" value={form.city} onChange={change} maxLength={100} placeholder="e.g. Chennai"/></label>
      <label className="text-sm">Guests<input className="input-dark mt-2" name="guests" type="number" min="1" max="1000000" value={form.guests} onChange={change} placeholder="e.g. 200"/></label>
      <label className="text-sm">Budget per supplier (₹)<input className="input-dark mt-2" name="budget" type="number" min="1" max="1000000000" step="0.01" value={form.budget} onChange={change} placeholder="Starting-price ceiling"/></label>
      <label className="text-sm">Event date<input className="input-dark mt-2" name="date" type="date" value={form.date} onChange={change}/></label>
      <label className="text-sm">Vendor category<select className="input-dark mt-2" name="category_id" value={form.category_id || ''} onChange={change}><option value="">All categories</option>{categories.map(c=><option value={c.id} key={c.id}>{c.name}</option>)}</select></label>
      <div className="sm:col-span-2 lg:col-span-4 flex flex-wrap gap-4 items-center"><button className="btn-gold" disabled={busy}>{busy?'Finding matches…':'Find my matches ✦'}</button><span className="text-xs text-gray-300">Starting prices only · Confirm final quotes and availability</span></div>
    </form>
    {error && <p role="alert" className="mt-5 text-red-300">{error}</p>}
    {results && <div aria-live="polite">
      <p className="text-sm text-gray-300 my-6">{results.note}</p>
      {['venues','vendors'].map(type=><section key={type} className="my-8"><h2 className="text-2xl capitalize mb-4">{type}</h2>
        {!results[type].length && <div className="card-dark p-6 text-gray-300">No matches. Try a different city, date, budget or guest count.</div>}
        <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-4">{results[type].map(item=><article className="card-dark p-5 flex flex-col" key={item.id}>
          <p className="text-xs text-gray-300">{item.city || 'City not listed'}{item.category?` · ${item.category}`:''}</p>
          <h3 className="text-xl my-2">{item.name || item.business_name}</h3>
          <p style={{color:'#e8c98a'}}>{item.starting_price ? `From ₹${item.starting_price.toLocaleString('en-IN')}`:'Request a quote'}</p>
          <p className="text-xs text-gray-300 my-3">{item.score} fit points · preference-based matching</p>
          <ul className="text-sm text-gray-200 space-y-2 mb-4">{item.reasons.map(x=><li key={x}>✓ {x}</li>)}</ul>
          <div className="text-xs text-gray-300 space-y-2 mt-auto">{item.warnings.map(x=><p key={x}>{x}</p>)}</div>
          <Feedback item={item}/>
          <Link to={type==='vendors'?`/vendors/${item.id}`:'/venues'} className="mt-5 underline" style={{color:'#e8c98a'}}>View {type==='vendors'?'supplier':'venue catalog'} →</Link>
        </article>)}</div>
      </section>)}
    </div>}
  </div>;
}

function Feedback({item}){const [notice,setNotice]=useState('');return <div className="text-xs mt-4"><button className="underline" onClick={async()=>{try{await api.post('/ai/feedback',{kind:item.kind,item_id:item.id,helpful:true});setNotice('Feedback saved.');}catch{setNotice('Could not save feedback.');}}}>This match is useful</button><span role="status" className="ml-2">{notice}</span></div>;}
