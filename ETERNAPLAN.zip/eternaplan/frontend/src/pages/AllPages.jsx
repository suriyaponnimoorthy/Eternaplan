// Legacy sample module retired. API-backed pages live in WorkspacePages.jsx.
