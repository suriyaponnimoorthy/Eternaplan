export { TasksPage as default } from '../WorkspacePages';
