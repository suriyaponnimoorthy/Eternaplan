export { GuestsPage as default } from '../WorkspacePages';
