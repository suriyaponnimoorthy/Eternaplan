export { EventDetailPage as default } from '../WorkspacePages';
