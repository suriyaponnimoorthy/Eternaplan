export { CreateEventPage as default } from '../WorkspacePages';
