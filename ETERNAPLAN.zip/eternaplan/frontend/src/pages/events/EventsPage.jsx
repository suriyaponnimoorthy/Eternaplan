export { EventsPage as default } from '../WorkspacePages';
