export { DashboardPage as default } from '../WorkspacePages';
