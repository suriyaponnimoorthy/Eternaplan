export { CalendarPage as default } from '../WorkspacePages';
