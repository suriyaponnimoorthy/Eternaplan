export { CustomerDetailPage as default } from '../WorkspacePages';
