export { CustomersPage as default } from '../WorkspacePages';
