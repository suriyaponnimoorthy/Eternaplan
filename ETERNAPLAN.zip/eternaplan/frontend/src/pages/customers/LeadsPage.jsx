export { LeadsPage as default } from '../WorkspacePages';
