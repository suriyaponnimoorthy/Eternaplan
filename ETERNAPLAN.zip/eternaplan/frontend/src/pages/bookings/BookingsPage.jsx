export { BookingsPage as default } from '../WorkspacePages';
