export { ReportsPage as default } from '../WorkspacePages';
