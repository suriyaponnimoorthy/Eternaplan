#!/bin/sh
# Run against an offsite restic snapshot in a NEW, isolated Compose project.
set -eu
cd "$(dirname "$0")/.."
: "${RESTIC_REPOSITORY:?Configure offsite restic storage}"
: "${RESTIC_PASSWORD_FILE:?Configure the repository password file}"
: "${RESTORE_SNAPSHOT:?Select the exact snapshot ID to verify}"
case "$RESTIC_REPOSITORY" in
  s3:*|b2:*|sftp:*|azure:*|gs:*|rest:https://*) ;;
  *) echo 'Use a remote repository backend for offsite verification.' >&2; exit 2;;
esac
case "$RESTORE_SNAPSHOT" in *[!0-9a-f]*|'') echo 'Use a hexadecimal snapshot ID.' >&2; exit 2;; esac
[ "${#RESTORE_SNAPSHOT}" -ge 8 ] || exit 2
project="eternaplan-recovery-$(date -u +%Y%m%d%H%M%S)"
work=$(mktemp -d)
umask 077
# Leave restored data private for inspection on failure. No production containers/volumes are deleted.
restic restore "$RESTORE_SNAPSHOT" --target "$work"
sql=$(find "$work" -type f -name database.sql)
documents=$(find "$work" -type f -name private-documents.tar)
manifest=$(find "$work" -type f -name recovery-manifest.json)
[ -f "$sql" ] && [ -f "$documents" ] && [ -f "$manifest" ] || { echo 'Snapshot must contain one SQL dump, private-file archive and recovery manifest.' >&2; exit 2; }
# Only the fresh project's database starts. Never start a restored email worker or public proxy.
docker compose -p "$project" -f docker-compose.yml up -d --wait --wait-timeout 180 db
docker compose -p "$project" -f docker-compose.yml exec -T db sh -c 'MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -uroot eternaplan_db' < "$sql"
docker compose -p "$project" -f docker-compose.yml run --rm --no-deps -T --user root --entrypoint sh backend -c 'tar -xf - -C /app/private-uploads && chown -R node:node /app/private-uploads' < "$documents"
docker compose -p "$project" -f docker-compose.yml run --rm --no-deps -T --entrypoint node backend scripts/recovery-manifest.js --compare < "$manifest" > "$work/evidence.json"
node - "$work/evidence.json" "$RESTORE_SNAPSHOT" "$project" <<'JS'
const fs=require('fs'),path=require('path');const evidence=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));
if(evidence.status!=='passed')process.exit(1);
const report={...evidence,generated_at:new Date().toISOString(),snapshot:process.argv[3],recovery_project:process.argv[4],offsite_repository_operator_confirmed:process.env.CONFIRM_OFFSITE_STORAGE==='true'};
fs.writeFileSync(path.resolve('offsite-recovery-evidence.json'),JSON.stringify(report,null,2)+'\n',{mode:0o600});
console.log(report.offsite_repository_operator_confirmed?'Recovery comparisons passed; offsite location confirmed by operator.':'Recovery comparisons passed; operator must confirm the repository is outside the application host.');
JS
# Release resources but preserve isolated volumes until the operator reviews the result.
docker compose -p "$project" -f docker-compose.yml stop db
printf 'Isolated recovery project retained for review: %s\n' "$project"
printf 'Temporary restored files are in the private directory: %s\n' "$work"
