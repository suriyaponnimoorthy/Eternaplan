import fs from 'node:fs';import crypto from 'node:crypto';
if(fs.existsSync('.env'))throw Error('.env already exists; refusing to overwrite existing secrets.');
const key=()=>crypto.randomBytes(32).toString('hex');
fs.writeFileSync('.env',`DB_ROOT_PASSWORD=${key()}\nDB_PASSWORD=${key()}\nJWT_SECRET=${key()}\nJWT_REFRESH_SECRET=${key()}\nDATA_ENCRYPTION_KEY=${key()}\nNODE_ENV=development\nFRONTEND_URL=http://localhost\nUPLOAD_SCAN_REQUIRED=true\nDOMAIN=\nACME_EMAIL=\nSMTP_HOST=\nSMTP_PORT=587\nSMTP_USER=\nSMTP_PASS=\nEMAIL_FROM=\nSTRIPE_SECRET_KEY=\nSTRIPE_WEBHOOK_SECRET=\nOPENAI_API_KEY=\nOPENAI_MODEL=\n`,{mode:0o600,flag:'wx'});
console.log('Created .env with unique secrets. Configure your domain and external providers before production. Keep DATA_ENCRYPTION_KEY securely backed up outside this project.');
