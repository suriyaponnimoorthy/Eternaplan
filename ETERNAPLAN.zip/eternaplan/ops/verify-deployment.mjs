import fs from 'node:fs';import os from 'node:os';import path from 'node:path';import dns from 'node:dns/promises';import {parseEnv} from 'node:util';import {spawnSync} from 'node:child_process';import {fileURLToPath,pathToFileURL} from 'node:url';
export function checkConfig(env){
 const missing=['DOMAIN','ACME_EMAIL','DB_PASSWORD','JWT_SECRET','JWT_REFRESH_SECRET','DATA_ENCRYPTION_KEY'].filter(k=>!env[k]);
 if(missing.length)return {status:'blocked',detail:`Configure: ${missing.join(', ')}.`};
 if(!/^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?\.[a-z]{2,}$/i.test(env.DOMAIN)||env.DOMAIN.includes('..'))return {status:'failed',detail:'DOMAIN must be a public hostname without a URL, port or path.'};
 if([env.JWT_SECRET,env.JWT_REFRESH_SECRET].some(x=>x.length<48)||env.JWT_SECRET===env.JWT_REFRESH_SECRET||!/^[a-f0-9]{64}$/i.test(env.DATA_ENCRYPTION_KEY))return {status:'failed',detail:'Signing/encryption secrets do not satisfy the required format.'};
 if(env.NODE_TLS_REJECT_UNAUTHORIZED==='0')return {status:'failed',detail:'TLS verification must not be disabled.'};
 return {status:'passed',detail:'Required production configuration is present; secret values are not included.'};
}
export function overall(checks){return checks.length>0&&checks.every(c=>c.status==='passed')?'passed':checks.some(c=>c.status==='failed')?'failed':'incomplete';}
export function composeHealthy(value){
 let rows;if(Array.isArray(value))rows=value;else if(typeof value==='string'){try{rows=JSON.parse(value);}catch{rows=value.split('\n').filter(Boolean).map(x=>JSON.parse(x));}}
 if(!Array.isArray(rows))rows=[rows];
 const required=['db','backend','worker','frontend','proxy','clamav'];
 return required.every(service=>rows.some(r=>r.Service===service&&r.State==='running'&&(!r.Health||r.Health==='healthy')));
}
async function main(){
 const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
 const fromFile=fs.existsSync(path.join(root,'.env'))?parseEnv(fs.readFileSync(path.join(root,'.env'),'utf8')):{};
 const env={...fromFile,...process.env},checks=[];
 const add=(name,result)=>{checks.push({name,...result});console.log(`${name}: ${result.status}`);};
 const run=(args,timeout=30000)=>spawnSync('docker',['compose','-f','docker-compose.yml','-f','docker-compose.production.yml',...args],{cwd:root,env,encoding:'utf8',timeout,maxBuffer:2*1024*1024});
 add('production_config',checkConfig(env));
 add('host_memory',os.totalmem()>=7*1024**3?{status:'passed',detail:'At least 7 GiB RAM is visible (suitable for an 8 GB-class starting host).'}:{status:'failed',detail:'Use an 8 GB-class host for this combined stack and verify memory under load.'});
 const engine=spawnSync('docker',['info','--format','{{.ServerVersion}}'],{encoding:'utf8',timeout:10000});
 add('docker_engine',engine.status===0?{status:'passed',detail:'Docker engine responded.'}:{status:'blocked',detail:'Docker engine is unavailable or this account cannot access it.'});
 if(engine.status===0){
  const config=run(['config','--quiet']);add('compose_config',config.status===0?{status:'passed',detail:'Production Compose configuration validated.'}:{status:'failed',detail:'Compose configuration did not validate. Inspect it on the host without sharing secret values.'});
  const state=run(['ps','--all','--format','json']);let healthy=false;try{healthy=state.status===0&&composeHealthy(state.stdout);}catch{}
  add('running_containers',healthy?{status:'passed',detail:'All six long-running services are running; any exposed health status is healthy.'}:{status:'failed',detail:'One or more required containers is stopped, missing or unhealthy.'});
  const migrations=run(['exec','-T','backend','node','-e',"require('./src/config/database').sequelize.query(\"SELECT name FROM schema_migrations WHERE name IN ('002_hardening.sql','003_security_workflow_fixes.sql','004_revoke_pending_resets.sql')\").then(([r])=>process.exit(r.length===3?0:1)).catch(()=>process.exit(1))"]);
  add('migration',migrations.status===0?{status:'passed',detail:'Hardening migration is recorded in the deployed database.'}:{status:'failed',detail:'Could not confirm the migration in the deployed database.'});
  for(const service of ['smtp','email','sms','scanner','stripe-test','webhook-ledger','ai']){
   const args=['exec','-T'];
   for(const key of ['VERIFY_EMAIL_TO','VERIFY_SEND_EMAIL','VERIFY_SMS_TO','VERIFY_SEND_SMS','VERIFY_AI','VERIFY_STRIPE_TEST','VERIFY_STRIPE_EVENT_ID','VERIFY_ORDER_ID'])if(env[key])args.push('-e',key);
   args.push('backend','node','scripts/verify-services.js',service);
   const response=run(args,90000);let result;try{result=JSON.parse(response.stdout.trim().split('\n').at(-1));}catch{result={status:'failed',detail:'Container check did not return a valid result.'};}
   if(!['passed','failed','blocked','pending'].includes(result.status))result={status:'failed',detail:'Invalid check status.'};add(service,result);
  }
 }else for(const name of ['compose_config','running_containers','migration','smtp','email','sms','scanner','stripe-test','webhook-ledger','ai'])add(name,{status:'blocked',detail:'Requires the configured deployment and running containers.'});
 if(checks.find(c=>c.name==='production_config').status==='passed'){
  try{await dns.resolve4(env.DOMAIN);add('dns',{status:'passed',detail:'The domain has an IPv4 DNS record; confirm it is your chosen server.'});}catch{add('dns',{status:'failed',detail:'Domain IPv4 DNS resolution failed.'});}
  for(const endpoint of ['health','ready'])try{const response=await fetch(`https://${env.DOMAIN}/${endpoint}`,{signal:AbortSignal.timeout(15000)}),data=await response.json();const ok=response.ok&&(endpoint==='ready'?data.ready===true:data.status==='healthy');add(`https_${endpoint}`,{status:ok?'passed':'failed',detail:ok?'Trusted HTTPS endpoint returned the expected health response.':'HTTPS endpoint did not return the expected application response.'});}catch{add(`https_${endpoint}`,{status:'failed',detail:'Trusted HTTPS endpoint could not be verified.'});}
  try{const response=await fetch(`https://${env.DOMAIN}/api/v1/billing/webhook`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}',signal:AbortSignal.timeout(15000)});add('unsigned_webhook_rejected',{status:response.status===400?'passed':response.status===503?'blocked':'failed',detail:response.status===400?'Unsigned webhook was rejected. Genuine signed delivery still requires the matching provider event check.':'Webhook rejection did not prove configured signature validation.'});}catch{add('unsigned_webhook_rejected',{status:'blocked',detail:'Could not reach the deployed webhook endpoint.'});}
 }else for(const name of ['dns','https_health','https_ready','unsigned_webhook_rejected'])add(name,{status:'blocked',detail:'Configure the production domain and secrets first.'});
 let recovery={status:'blocked',detail:'Run the isolated recovery drill with the offsite repository and preserve its evidence. A local file copy is not offsite recovery.'};
 try{const evidence=JSON.parse(fs.readFileSync(path.resolve(env.RECOVERY_EVIDENCE_FILE||path.join(root,'offsite-recovery-evidence.json')),'utf8')),age=Date.now()-new Date(evidence.generated_at).getTime();
  if(evidence.status==='passed'&&evidence.offsite_repository_operator_confirmed===true&&evidence.tables_verified>=10&&/^[a-f0-9]{8,64}$/.test(evidence.snapshot)&&age>=0&&age<86400000)recovery={status:'passed',detail:'Fresh recovery comparisons passed against an operator-confirmed offsite snapshot. Review retained evidence and recovery project.'};
 }catch{}
 add('offsite_restore',recovery);
 const report={generated_at:new Date().toISOString(),overall:overall(checks),checks};
 const output=path.resolve(env.VERIFICATION_REPORT||path.join(root,'deployment-verification.json'));fs.writeFileSync(output,JSON.stringify(report,null,2)+'\n',{mode:0o600});
 console.log(`Overall: ${report.overall}. Report saved.`);if(report.overall!=='passed')process.exitCode=2;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href)main().catch(()=>{console.error('Deployment verification could not finish. Inspect the host configuration.');process.exitCode=1;});
