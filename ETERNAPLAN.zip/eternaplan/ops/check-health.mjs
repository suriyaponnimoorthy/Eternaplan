const base=process.env.HEALTHCHECK_URL;
if(!base)throw Error('Set HEALTHCHECK_URL to your HTTPS origin');
for(const path of ['/health','/ready']){const response=await fetch(base+path,{signal:AbortSignal.timeout(10000)});if(!response.ok)throw Error(`${path} failed (${response.status})`);}
console.log('Liveness and readiness passed.');
