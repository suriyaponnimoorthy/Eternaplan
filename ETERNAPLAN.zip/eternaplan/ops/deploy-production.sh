#!/bin/sh
# Run on the selected server after configuring .env, DNS and provider accounts.
set -eu
cd "$(dirname "$0")/.."
[ -f .env ] || { echo 'Create .env with node ops/create-env.mjs, then configure it.' >&2; exit 2; }
docker info >/dev/null
# Never print resolved Compose configuration: it contains secrets.
docker compose -f docker-compose.yml -f docker-compose.production.yml config --quiet
docker compose -f docker-compose.yml -f docker-compose.production.yml up --build -d --wait --wait-timeout 600
node ops/verify-deployment.mjs
