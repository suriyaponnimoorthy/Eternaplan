#!/bin/sh
# Run from the project root on a host with Docker Compose, restic and an offsite repository.
set -eu
: "${RESTIC_REPOSITORY:?Set an offsite restic repository}"
: "${RESTIC_PASSWORD_FILE:?Set RESTIC_PASSWORD_FILE outside this repository}"
compose_files='docker-compose.yml'
if [ "${BACKUP_PRODUCTION:-true}" = true ]; then compose_files='docker-compose.yml:docker-compose.production.yml'; fi
export COMPOSE_FILE="$compose_files"
umask 077
work=$(mktemp -d)
trap 'rm -rf "$work"' EXIT
# Pause writers so the SQL dump and encrypted document snapshot are consistent.
docker compose stop backend worker
trap 'docker compose start backend worker; rm -rf "$work"' EXIT
docker compose exec -T db sh -c 'MYSQL_PWD="$MYSQL_PASSWORD" mysqldump -ueternaplan --single-transaction --no-tablespaces --routines --triggers eternaplan_db' > "$work/database.sql"
# A temporary read-only mount copies ciphertext, never public links or decrypted documents.
docker compose run --rm --no-deps -T --user root --entrypoint tar backend -C /app/private-uploads -cf - . > "$work/private-documents.tar"
docker compose run --rm --no-deps -T --entrypoint node backend scripts/recovery-manifest.js > "$work/recovery-manifest.json"
docker compose start backend worker
restic backup --tag eternaplan "$work/database.sql" "$work/private-documents.tar" "$work/recovery-manifest.json"
restic check
# Retention intentionally requires an explicit operator policy; no automatic snapshot deletion.
