#!/bin/sh
# Restore into an isolated recovery deployment only.
set -eu
: "${RESTORE_CONFIRM:?Set RESTORE_CONFIRM=isolated-recovery after selecting an isolated deployment}"
[ "$RESTORE_CONFIRM" = isolated-recovery ] || exit 1
: "${RESTORE_SQL:?Set RESTORE_SQL to restored database.sql}"
: "${RESTORE_DOCUMENTS:?Set RESTORE_DOCUMENTS to restored private-documents.tar}"
docker compose stop backend worker
docker compose exec -T db sh -c 'MYSQL_PWD="$MYSQL_ROOT_PASSWORD" mysql -uroot eternaplan_db' < "$RESTORE_SQL"
docker compose run --rm --no-deps -T --user root --entrypoint sh backend -c 'tar -xf - -C /app/private-uploads && chown -R node:node /app/private-uploads' < "$RESTORE_DOCUMENTS"
docker compose start backend worker
# Validate row counts, one authorized document download, an invoice and /ready before considering recovery complete.
