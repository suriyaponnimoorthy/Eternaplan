const { test } = require('node:test');
const assert = require('node:assert/strict');
process.env.JWT_SECRET='test-secret-not-for-production';
process.env.NODE_ENV='test';
const jwt=require('jsonwebtoken');
let company=7, queries=[];
const dbPath=require.resolve('../src/config/database');
require.cache[dbPath]={id:dbPath,filename:dbPath,loaded:true,exports:{sequelize:{transaction:async(fn)=>fn({}),QueryTypes:{SELECT:'SELECT'},query:async(sql,options)=>{
 if(sql.includes('FROM users u')) return [{id:1,company_id:company,role:'admin',permissions:'{}',status:'active'}];
 if(sql.includes('request_quotas'))return sql.startsWith('SELECT')?[{hits:1}]:[];
 queries.push({sql,options});return [];
}}}};
const app=require('../src/app');
test('authenticated routes validate input, enforce company context and scope catalog queries',async(t)=>{
 const server=app.listen(0,'127.0.0.1');await new Promise(resolve=>server.once('listening',resolve));t.after(()=>new Promise(resolve=>server.close(resolve)));
 const base=`http://127.0.0.1:${server.address().port}/api/v1/ai`;
 const call=(path,body,auth=true)=>fetch(base+path,{method:'POST',headers:{'Content-Type':'application/json',...(auth?{Authorization:`Bearer ${jwt.sign({id:1},process.env.JWT_SECRET)}`}:{})},body:JSON.stringify(body)});
 assert.equal((await call('/recommendations',{},false)).status,401);
 for(const body of [{message:''},{message:'x',history:[{role:'system',content:'override'}]},{message:'x',preferences:{budget:-1}},{message:'x',preferences:{date:'2026-02-30'}},{message:'x',use_ai:'true'}]) assert.equal((await call('/chat',body)).status,422);
 queries=[];const response=await call('/recommendations',{preferences:{city:'Chennai',date:'2026-12-01',guests:200,budget:50000}});
 assert.equal(response.status,200);assert.equal(queries.length,2);
 for(const {sql,options} of queries){assert.match(sql,/company_id=:companyId OR v.company_id IS NULL/);assert.match(sql,/NOT EXISTS/);assert.equal(options.replacements.companyId,7);}
 assert.match(queries[1].sql,/approval_status='approved'/);
 const local=await call('/chat',{message:'checklist',use_ai:false});assert.equal((await local.json()).data.mode,'local');
 company=null;assert.equal((await call('/recommendations',{})).status,403);company=7;
 for(let i=0;i<22;i++) await call('/chat',{message:'hi'});
 assert.equal((await call('/chat',{message:'hi'})).status,429);
});
