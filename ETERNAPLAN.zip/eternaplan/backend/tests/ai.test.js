const { test } = require('node:test');
const assert = require('node:assert/strict');
const { rankCandidates } = require('../src/services/recommendations');
const { answer } = require('../src/services/assistant');
const rows = [
 {id:1,name:'Large',city:'Chennai',capacity_max:500,base_price:50000,rating:5,total_reviews:10},
 {id:2,name:'Right size',city:'Chennai',capacity_max:200,base_price:45000,rating:5,total_reviews:10},
 {id:3,name:'Too small',city:'Chennai',capacity_max:50,base_price:10000},
 {id:4,name:'Elsewhere',city:'Delhi',capacity_max:200,base_price:30000},
 {id:5,name:'Expensive',city:'Chennai',capacity_max:200,base_price:90000},
];
test('matching excludes capacity, city and budget mismatches; rewards tighter capacity fit',()=>{
 const result=rankCandidates(rows,{city:' chennai ',guests:200,budget:60000},'venue');
 assert.deepEqual(result.map(x=>x.id),[2,1]);
 assert.ok(result[0].reasons.some(x=>x.includes('Capacity')));
});
test('unknown prices stay unknown and missing reviews do not earn review points',()=>{
 const result=rankCandidates([{id:1,min_price:null,rating:5,total_reviews:0}],{budget:10000},'vendor')[0];
 assert.equal(result.starting_price,null);assert.equal(result.score,0);
 assert.ok(result.warnings.some(x=>x.includes('Price unavailable')));
});
test('vendor category is a hard filter',()=>{
 assert.equal(rankCandidates([{id:1,category_id:2}],{category_id:1},'vendor').length,0);
});
const context={venues:[],vendors:[]};
test('local mode never calls provider',async()=>{
 const result=await answer({message:'budget',history:[],context,useAI:false,fetchImpl:()=>{throw Error('must not call');}});
 assert.equal(result.mode,'local');assert.match(result.reply,/total budget/);
});
test('provider failure and refusal degrade to labeled local guidance',async()=>{
 process.env.OPENAI_API_KEY='test';process.env.OPENAI_MODEL='test-model';
 for(const fetchImpl of [async()=>{throw Error('offline');},async()=>({ok:true,json:async()=>({status:'completed',output:[{type:'message',content:[{type:'refusal'}]}]})})]) {
  const result=await answer({message:'checklist',history:[],context,useAI:true,fetchImpl});
  assert.equal(result.mode,'local');assert.match(result.notice,/unavailable/);
 }
});
test('provider request is bounded, stateless and grounded; extracts Responses text',async()=>{
 const result=await answer({message:'help',history:[],context,useAI:true,fetchImpl:async(url,options)=>{
  const payload=JSON.parse(options.body);assert.equal(payload.store,false);assert.equal(payload.max_output_tokens,900);
  assert.equal(url,'https://api.openai.com/v1/responses');assert.match(payload.instructions,/no tools/);
  return {ok:true,json:async()=>({status:'completed',output:[{type:'message',content:[{type:'output_text',text:'Planning advice'}]}]})};
 }});assert.equal(result.mode,'ai');assert.equal(result.reply,'Planning advice');
});
