const {test,before,after}=require('node:test'),assert=require('node:assert/strict'),mysql=require('mysql2/promise'),fs=require('fs'),path=require('path'),bcrypt=require('bcryptjs');
const enabled=process.env.RUN_MYSQL_TESTS==='1';
const database=`eternaplan_test_${process.pid}_${Date.now()}`;
let db,server,base,sequelize,fixture={},billing,generateTokens;
const config={host:process.env.TEST_DB_HOST||'127.0.0.1',port:Number(process.env.TEST_DB_PORT)||3306,user:process.env.TEST_DB_USER||'root',password:process.env.TEST_DB_PASSWORD||''};
async function importSchema(connection){let delimiter=';',buffer='',comment=false;const sql=fs.readFileSync(path.resolve(__dirname,'../../../database/schema.sql'),'utf8').replaceAll('eternaplan_db',database);for(const line of sql.split('\n')){const s=line.trim();if(comment){if(s.includes('*/'))comment=false;continue;}if(s.startsWith('/*')){comment=!s.includes('*/');continue;}if(!s||s.startsWith('--'))continue;if(s.startsWith('DELIMITER ')){delimiter=s.slice(10).trim();continue;}buffer+=line+'\n';if(s.endsWith(delimiter)){await connection.query(buffer.trim().slice(0,-delimiter.length));buffer='';}}}
const auth=(who='a')=>({Authorization:`Bearer ${generateTokens(fixture[who]).accessToken}`});
const call=(method,url,body,who='a')=>fetch(base+url,{method,headers:{...auth(who),'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)});
const json=async r=>{const d=await r.json();assert.ok(r.ok,`${r.status}: ${JSON.stringify(d)}`);return d.data;};
before(async()=>{
 if(!enabled)return;
 process.env.NODE_ENV='test';process.env.RATE_LIMIT_MAX='1000';process.env.DB_NAME=database;process.env.DB_HOST=config.host;process.env.DB_PORT=config.port;process.env.DB_USER=config.user;process.env.DB_PASSWORD=config.password;
 process.env.JWT_SECRET='a'.repeat(64);process.env.JWT_REFRESH_SECRET='b'.repeat(64);process.env.DATA_ENCRYPTION_KEY='c'.repeat(64);process.env.FRONTEND_URL='http://localhost:3000';process.env.STRIPE_WEBHOOK_SECRET='whsec_test';
 db=await mysql.createConnection(config);await importSchema(db);await require('../../scripts/migrate').migrate({...config,database});
 const password=await bcrypt.hash('TestPassword123!',4);
 for(const [name,i] of [['a',1],['b',2]]){
  const [c]=await db.query('INSERT INTO companies (name,slug,email) VALUES (?,?,?)',[name,name,`${name}@test.local`]);
  const [u]=await db.query("INSERT INTO users (company_id,role_id,first_name,last_name,email,password_hash,status) VALUES (?,2,'Test','Planner',?,?,'active')",[c.insertId,`${name}@test.local`,password]);
  const [cust]=await db.query("INSERT INTO customers (company_id,first_name,last_name,phone) VALUES (?,'Client',?,'1234567890')",[c.insertId,name]);
  fixture[name]={id:u.insertId,company_id:c.insertId,token_version:0,customer_id:cust.insertId};
 }
 const [v]=await db.query("INSERT INTO venues (company_id,name,address,city,capacity_max,base_price) VALUES (NULL,'Shared Hall','Test road','Chennai',300,50000)");fixture.venue=v.insertId;
 const [vendor]=await db.query("INSERT INTO vendors (company_id,category_id,business_name,phone,city,approval_status,min_price) VALUES (NULL,1,'Test Supplier','123','Chennai','approved',1000)");fixture.vendor=vendor.insertId;
 const mod=require('../../src/config/database');sequelize=mod.sequelize;billing=require('../../src/services/billing');generateTokens=require('../../src/utils/jwt').generateTokens;
 server=require('../../src/app').listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));base=`http://127.0.0.1:${server.address().port}/api/v1`;
});
after(async()=>{if(!enabled)return;if(server)await new Promise(r=>server.close(r));if(sequelize)await sequelize.close();if(db){if(process.env.KEEP_TEST_DB==='1'){console.log('Retained test database:',database);if(process.env.TEST_FIXTURE_OUTPUT)fs.writeFileSync(process.env.TEST_FIXTURE_OUTPUT,JSON.stringify({database,fixture}));}else await db.query(`DROP DATABASE IF EXISTS ${database}`);await db.end();}});
const it=(name,fn)=>test(name,{skip:!enabled},fn);
it('schema migrations apply and rerun without changing history',async()=>{await require('../../scripts/migrate').migrate({...config,database});const [r]=await db.query('SELECT * FROM schema_migrations');assert.equal(r.length,3);});
it('two companies cannot read or mutate each other records or cross-link resources',async()=>{
 assert.equal((await call('GET',`/customers/${fixture.b.customer_id}`)).status,404);
 assert.equal((await call('POST',`/customers/${fixture.b.customer_id}/notes`,{note:'unauthorized'})).status,404);
 assert.equal((await call('POST','/events',{customer_id:fixture.b.customer_id,event_name:'Wrong',event_date:'2027-01-01'})).status,404);
});
it('mixed-case and encoded paths cannot bypass company and role checks',async()=>{
 const [vendor]=await db.query("INSERT INTO vendors (company_id,category_id,business_name,phone,city) VALUES (?,1,'Private Supplier','123','Chennai')",[fixture.b.company_id]);
 const id=vendor.insertId,encoded=String(id).split('').map(x=>'%'+x.charCodeAt(0).toString(16)).join('');
 assert.equal((await call('GET',`/vendors/${id}`)).status,404);
 assert.equal((await call('GET',`/VeNdOrS/${id}`)).status,404);
 assert.equal((await call('GET',`/vendors/${encoded}`)).status,400);
 assert.equal((await call('GET',`/vendors/${fixture.vendor}`)).status,200);
 const password=await bcrypt.hash('StaffPassword123!',4);
 const [staff]=await db.query("INSERT INTO users (company_id,role_id,first_name,last_name,email,password_hash,status) VALUES (?,3,'Staff','Planner','staff@test.local',?,'active')",[fixture.a.company_id,password]);
 fixture.staff={id:staff.insertId,token_version:0};
 const expense={description:'Unauthorized expense',category:'Test',amount:'2.00',expense_date:'2027-01-01'};
 assert.equal((await call('POST','/finance/expenses',expense,'staff')).status,403);
 assert.equal((await call('POST','/fInAnCe/expenses',expense,'staff')).status,404);
 const [rows]=await db.query('SELECT id FROM expenses WHERE description=?',[expense.description]);
 assert.equal(rows.length,0);
});
it('overlapping concurrent event reservations allow exactly one winner',async()=>{
 const data={customer_id:fixture.a.customer_id,event_name:'Concurrent',event_date:'2027-01-01',event_time:'10:00',end_time:'12:00',venue_id:fixture.venue};
 const responses=await Promise.all([call('POST','/events',data),call('POST','/events',data)]);assert.deepEqual(responses.map(r=>r.status).sort(),[201,409]);
 const result=await json(responses.find(r=>r.status===201));fixture.event=result.id;
 const adjacent=await call('POST','/events',{...data,event_name:'Adjacent',event_time:'12:00',end_time:'13:00'});assert.equal(adjacent.status,201);
});
it('guest and nested task ownership is enforced, including child-parent mismatch',async()=>{
 const guest=await json(await call('POST','/guests',{event_id:fixture.event,first_name:'Guest'}));fixture.guest=guest.id;
 assert.equal((await call('PATCH',`/guests/${guest.id}/check-in`,{},'b')).status,404);
 assert.equal((await call('GET',`/guests?event_id=${fixture.event}`,undefined,'b')).status,404);
 const task=await json(await call('POST',`/events/${fixture.event}/tasks`,{title:'Task'}));
 const e=await json(await call('POST','/events',{customer_id:fixture.a.customer_id,event_name:'Another',event_date:'2027-02-01'}));
 assert.equal((await call('PATCH',`/events/${e.id}/tasks/${task.id}`,{status:'completed'})).status,404);
});
it('supplier concurrency, cancellation and booking restoration use the same lock',async()=>{
 const b={event_id:fixture.event,vendor_id:fixture.vendor,booking_type:'vendor',booking_date:'2027-01-01',start_time:'10:00',end_time:'12:00',agreed_price:'100'};
 const rs=await Promise.all([call('POST','/bookings',b),call('POST','/bookings',b)]);assert.deepEqual(rs.map(x=>x.status).sort(),[201,409]);
 const booking=await json(rs.find(x=>x.status===201));await json(await call('PATCH',`/bookings/${booking.id}/status`,{status:'cancelled'}));
 const newer=await call('POST','/bookings',b);assert.equal(newer.status,201);
 assert.equal((await call('PATCH',`/bookings/${booking.id}/status`,{status:'confirmed'})).status,409);
});
it('a cancelled parent event blocks reactivation of a cancelled booking',async()=>{
 const event=await json(await call('POST','/events',{customer_id:fixture.a.customer_id,event_name:'Cancelled parent',event_date:'2027-04-12'}));
 const booking=await json(await call('POST','/bookings',{event_id:event.id,vendor_id:fixture.vendor,booking_type:'vendor',booking_date:'2027-04-12',agreed_price:'10'}));
 await json(await call('PATCH',`/bookings/${booking.id}/status`,{status:'cancelled'}));
 await json(await call('PUT',`/events/${event.id}`,{status:'cancelled'}));
 assert.equal((await call('PATCH',`/bookings/${booking.id}/status`,{status:'confirmed'})).status,409);
 const [[row]]=await db.query('SELECT status FROM bookings WHERE id=?',[booking.id]);assert.equal(row.status,'cancelled');
});
it('invoice money, manual idempotency, checkout capture, duplicate and refund reconciliation remain exact',async()=>{
 const invoice=await json(await call('POST','/finance/invoices',{event_id:fixture.event,customer_id:fixture.a.customer_id,subtotal:'100.00',tax_rate:0,due_date:'2027-01-01'}));fixture.invoice=invoice.id;
 const manual={invoice_id:invoice.id,amount:'30.00',payment_method:'upi',payment_date:'2026-04-15',payment_ref:'UPI-RCPT-2026',payment_type:'partial',request_key:'manual-test-123456789'};
 await json(await call('POST','/finance/payments',manual));await json(await call('POST','/finance/payments',manual));
 assert.equal((await call('POST','/finance/payments',{...manual,amount:'31'})).status,409);
 assert.equal((await call('POST','/finance/payments',{...manual,payment_ref:'changed'})).status,409);
 assert.equal((await call('POST','/finance/payments',{...manual,payment_date:'2026-02-31'})).status,422);
 const [[receipt]]=await db.query("SELECT payment_method,DATE_FORMAT(payment_date,'%Y-%m-%d') AS receipt_date,payment_ref,payment_type,gateway_txn_id FROM payments WHERE invoice_id=?",[invoice.id]);
 assert.deepEqual(receipt,{payment_method:'upi',receipt_date:'2026-04-15',payment_ref:'UPI-RCPT-2026',payment_type:'partial',gateway_txn_id:null});
 let session;const client={accounts:{retrieve:async()=>({id:'acct_test'})},checkout:{sessions:{create:async(params,opts)=>{assert.ok(opts.idempotencyKey);assert.equal(params.line_items[0].price_data.unit_amount,7000);return session={id:'cs_test_1',url:'https://checkout.stripe.com/test',amount_total:7000,currency:'inr',client_reference_id:params.client_reference_id,metadata:params.metadata,payment_intent:'pi_test_1',payment_status:'unpaid',status:'open'};},retrieve:async()=>session}},refunds:{create:async p=>({id:'re_test_1',payment_intent:p.payment_intent,amount:p.amount,currency:'inr',metadata:p.metadata,status:'succeeded'}),list:async()=>({data:[],has_more:false})}};
 const order=await billing.checkout(fixture.a.company_id,invoice.id,'checkout-test-123456789',client);fixture.order=order.id;
 const again=await billing.checkout(fixture.a.company_id,invoice.id,'checkout-test-123456789',client);assert.equal(again.id,order.id);
 session.payment_status='paid';session.status='complete';
 await billing.reconcile(fixture.a.company_id,order.id,client);await billing.reconcile(fixture.a.company_id,order.id,client);
 let [rows]=await db.query('SELECT amount_paid,balance_due FROM invoices WHERE id=?',[invoice.id]);assert.equal(rows[0].amount_paid,'100.00');assert.equal(rows[0].balance_due,'0.00');
 await billing.refund(fixture.a.company_id,order.id,2000,'refund-test-123456789',client);await billing.refund(fixture.a.company_id,order.id,2000,'refund-test-123456789',client);
 [rows]=await db.query('SELECT amount_paid,balance_due FROM invoices WHERE id=?',[invoice.id]);assert.equal(rows[0].amount_paid,'80.00');assert.equal(rows[0].balance_due,'20.00');
 await assert.rejects(()=>billing.refund(fixture.a.company_id,order.id,6000,'refund-over-123456789',client));
 const [ledger]=await db.query('SELECT COUNT(*) AS n,SUM(amount_minor) AS net FROM billing_ledger WHERE invoice_id=?',[invoice.id]);assert.equal(ledger[0].n,3);assert.equal(Number(ledger[0].net),8000);
});
it('checkout can recover a lost provider response by order ID and safely expire the session',async()=>{
 const invoice=await json(await call('POST','/finance/invoices',{event_id:fixture.event,customer_id:fixture.a.customer_id,subtotal:'10.00',tax_rate:0,due_date:'2027-01-01'}));
 const company=fixture.a.company_id,key='recovery-test-123456789';
 let session,attempts=0,providerKey,originalPayload;
 const client={accounts:{retrieve:async()=>({id:'acct_test'})},checkout:{sessions:{
  create:async(params,opts)=>{
   attempts++;
   if(session){assert.equal(opts.idempotencyKey,providerKey);assert.deepEqual(params,originalPayload);return session;}
   providerKey=opts.idempotencyKey;originalPayload=params;
   session={id:'cs_recovery',url:'https://checkout.stripe.com/test',amount_total:1000,currency:'inr',client_reference_id:params.client_reference_id,metadata:params.metadata,payment_status:'unpaid',status:'open'};
   throw new Error('Connection lost after provider committed');
  },
  retrieve:async()=>session,expire:async()=>({...session,status:'expired',url:null}),
  list:async()=>({data:[],has_more:true})
 }}};
 const pending=await billing.checkout(company,invoice.id,key,client);
 assert.equal(pending.state,'recovery_required');
 const manual={invoice_id:invoice.id,amount:'10.00',request_key:'manual-after-123456789'};
 assert.equal((await call('POST','/finance/payments',manual)).status,409);
 await assert.rejects(billing.checkout(company,invoice.id,'second-attempt-123456789',client),{statusCode:409});
 await assert.rejects(billing.recoverCheckout(fixture.b.company_id,pending.id,'retry',client),{statusCode:404});
 await assert.rejects(billing.recoverCheckout(company,pending.id,'retry',{...client,accounts:{retrieve:async()=>({id:'acct_wrong'})}}),{statusCode:409});
 assert.equal((await billing.reconcile(company,pending.id,client)).state,'recovery_required');
 const restored=await billing.recoverCheckout(company,pending.id,'retry',client);
 assert.equal(restored.state,'open');assert.equal(attempts,2);
 assert.equal((await billing.recoverCheckout(company,pending.id,'cancel',client)).state,'expired');
 assert.equal((await billing.recoverCheckout(company,pending.id,'retry',client)).state,'expired');
 assert.equal(attempts,2);
 await json(await call('POST','/finance/payments',manual));
});
it('checkout releases a missing session only after a complete search on the recorded account',async()=>{
 const invoice=await json(await call('POST','/finance/invoices',{event_id:fixture.event,customer_id:fixture.a.customer_id,subtotal:'10.00',tax_rate:0,due_date:'2027-01-01'}));
 const company=fixture.a.company_id;
 const client={accounts:{retrieve:async()=>({id:'acct_test'})},checkout:{sessions:{
  create:async()=>{throw new Error('Connection lost');},
  list:async()=>({data:[],has_more:false})
 }}};
 const order=await billing.checkout(company,invoice.id,'absence-test-123456789',client);
 assert.equal((await billing.reconcile(company,order.id,client)).state,'recovery_required');
 await db.query('UPDATE billing_orders SET created_at=DATE_SUB(NOW(),INTERVAL 25 HOUR) WHERE id=?',[order.id]);
 assert.equal((await billing.reconcile(company,order.id,client)).state,'failed');
 await json(await call('POST','/finance/payments',{invoice_id:invoice.id,amount:'10.00',request_key:'verified-absent-123456789'}));
});
it('real Stripe signature validation rejects forged bodies and deduplicates signed deliveries',async()=>{
 const Stripe=require('stripe'),s=new Stripe('sk_test_dummy'),payload=JSON.stringify({id:'evt_test_one',type:'ignored.event',data:{object:{id:'ignored'}}});
 const client={webhooks:s.webhooks};const header=s.webhooks.generateTestHeaderString({payload,secret:process.env.STRIPE_WEBHOOK_SECRET});
 await assert.rejects(()=>billing.webhook(Buffer.from(payload+' '),header,client));
 await billing.webhook(Buffer.from(payload),header,client);await billing.webhook(Buffer.from(payload),header,client);
 const [events]=await db.query("SELECT COUNT(*) AS n FROM billing_webhook_events WHERE id='evt_test_one'");assert.equal(events[0].n,1);
 process.env.STRIPE_SECRET_KEY='sk_test_dummy';
 const response=await fetch(base+'/billing/webhook',{method:'POST',headers:{'Content-Type':'application/json','Stripe-Signature':'forged'},body:payload});assert.equal(response.status,400);
 const valid=await fetch(base+'/billing/webhook',{method:'POST',headers:{'Content-Type':'application/json','Stripe-Signature':header},body:payload});assert.equal(valid.status,200);
});
it('private uploads are encrypted and isolated; public static route is gone',async()=>{
 const form=new FormData();form.append('file',new Blob([Buffer.from('%PDF-test-private')],{type:'application/pdf'}),'test.pdf');
 const result=await json(await fetch(base+'/documents',{method:'POST',headers:auth(),body:form}));
 assert.equal((await call('GET',`/documents/${result.id}`,undefined,'b')).status,404);
 const download=await call('GET',`/documents/${result.id}`);assert.equal(await download.text(),'%PDF-test-private');
 const bytes=fs.readFileSync(path.resolve(process.env.PRIVATE_UPLOAD_DIR||'private-uploads',result.id));assert.notEqual(bytes.toString(),'%PDF-test-private');
 assert.equal((await fetch(base.replace('/api/v1','')+'/uploads/test.pdf')).status,404);
});
it('customer role is denied staff workspace and sees only linked event portal',async()=>{
 const [u]=await db.query("INSERT INTO users(company_id,role_id,first_name,last_name,email,password_hash,status,customer_id) VALUES (?,5,'Own','Customer','customer@test.local','unused','active',?)",[fixture.a.company_id,fixture.a.customer_id]);fixture.customer={id:u.insertId,token_version:0};
 assert.equal((await call('GET','/customers',undefined,'customer')).status,403);
 const data=await json(await call('GET','/portal',undefined,'customer'));assert.ok(data.length>0);assert.ok(data.every(x=>x.id));
});
it('logout revokes old access token immediately',async()=>{
 const token=auth('b');const response=await fetch(base+'/auth/logout',{method:'POST',headers:token});assert.equal(response.status,200);
 assert.equal((await fetch(base+'/auth/me',{headers:token})).status,401);
});

it('real catalog queries and shared quotas run against MySQL',async()=>{
 const r=await json(await call('POST','/ai/recommendations',{preferences:{city:'Chennai',guests:200,budget:100000,date:'2027-06-01'}}));assert.equal(r.venues[0].name,'Shared Hall');
 const c=await json(await call('POST','/ai/chat',{message:'Recommend a venue',use_ai:false,preferences:{city:'Chennai'}}));assert.equal(c.mode,'local');
 const [q]=await db.query('SELECT COUNT(*) AS n FROM request_quotas');assert.ok(q[0].n>=2);
});
it('transactional signup, hashed OTP, refresh rotation and reset revocation',async()=>{
 const signup=await call('POST','/auth/register',{company_name:'New Company',first_name:'New',last_name:'Owner',email:'new@test.local',phone:'1234567890',password:'NewPassword123!'});assert.equal(signup.status,201);
 const [jobs]=await db.query("SELECT payload FROM notification_jobs WHERE kind='email' ORDER BY created_at DESC LIMIT 1");
 const {open}=require('../../src/utils/crypto'),job=JSON.parse(open(typeof jobs[0].payload==='string'?JSON.parse(jobs[0].payload):jobs[0].payload).toString()),otp=job.context.otp;
 const [users]=await db.query("SELECT otp_code FROM users WHERE email='new@test.local'");assert.notEqual(users[0].otp_code,otp);
 await json(await call('POST','/auth/verify-otp',{email:'new@test.local',otp}));
 const login=await call('POST','/auth/login',{email:'new@test.local',password:'NewPassword123!'});assert.equal(login.status,200);const data=(await login.json()).data,cookie=login.headers.get('set-cookie').split(';')[0];
 const refresh=await fetch(base+'/auth/refresh',{method:'POST',headers:{Cookie:cookie,'Content-Type':'application/json'},body:'{}'});assert.equal(refresh.status,200);
 const reused=await fetch(base+'/auth/refresh',{method:'POST',headers:{Cookie:cookie,'Content-Type':'application/json'},body:'{}'});assert.equal(reused.status,401);
 const secret='d'.repeat(64);await db.query("UPDATE users SET password_reset_token=?,password_reset_expires=DATE_ADD(NOW(),INTERVAL 10 MINUTE) WHERE email='new@test.local'",[require('../../src/utils/crypto').hash(secret)]);
 await json(await call('POST','/auth/reset-password',{token:secret,password:'ChangedPassword123!'}));
 const revoked=await fetch(base+'/auth/me',{headers:{Authorization:`Bearer ${data.token}`}});assert.equal(revoked.status,401);
});
it('invitations bind staff to the issuing company and are single use',async()=>{
 await json(await call('POST','/team/invitations',{email:'invited@test.local',role:'event_manager'}));
 const [rows]=await db.query("SELECT payload FROM notification_jobs WHERE kind='email'");const {open}=require('../../src/utils/crypto');const jobs=rows.map(r=>JSON.parse(open(typeof r.payload==='string'?JSON.parse(r.payload):r.payload).toString()));const j=jobs.find(j=>j.to==='invited@test.local');const token=j.html.split('token=')[1];
 const b={token,first_name:'Invited',last_name:'Staff',password:'InvitedPassword123!'};await json(await call('POST','/team/accept',b));assert.equal((await call('POST','/team/accept',b)).status,400);
 const [u]=await db.query("SELECT company_id,role_id FROM users WHERE email='invited@test.local'");assert.equal(u[0].company_id,fixture.a.company_id);assert.equal(u[0].role_id,3);
});
it('MFA requires fresh credentials, expires pending enrollment and rejects factor replacement and replay',async()=>{
 const credentials={email:'mfa@test.local',password:'MfaPassword123!'};
 const password=await bcrypt.hash(credentials.password,4);
 const [u]=await db.query("INSERT INTO users(company_id,role_id,first_name,last_name,email,password_hash,status) VALUES (?,2,'Mfa','Owner',?,?,'active')",[fixture.a.company_id,credentials.email,password]);
 fixture.mfa={id:u.insertId,token_version:0};
 const totp=require('../../src/utils/totp');
 const setup=async()=>json(await call('POST','/mfa/setup',{password:credentials.password},'mfa'));
 const update=(action,code,password=credentials.password)=>call('POST',`/mfa/${action}`,{code,password},'mfa');
 assert.equal((await call('POST','/mfa/setup',{},'mfa')).status,422);
 assert.equal((await call('POST','/mfa/setup',{password:'incorrect'},'mfa')).status,403);
 const old=await setup();
 await db.query('UPDATE users SET mfa_pending_expires_at=DATE_SUB(NOW(),INTERVAL 1 SECOND) WHERE id=?',[u.insertId]);
 assert.equal((await update('enable',totp.token(old.secret,Math.floor(Date.now()/30000)))).status,400);
 const active=await setup(),step=Math.floor(Date.now()/30000);
 const firstCode=totp.token(active.secret,step-1);
 await json(await update('enable',firstCode));
 assert.equal((await call('GET','/auth/me',undefined,'mfa')).status,401);
 assert.equal((await call('POST','/auth/login',{...credentials,totp:firstCode})).status,401);
 assert.equal((await call('POST','/auth/login',{...credentials,totp:totp.token(active.secret,step)})).status,200);
 fixture.mfa.token_version=1;
 assert.equal((await call('POST','/mfa/setup',{password:credentials.password},'mfa')).status,409);
 assert.equal((await update('enable',totp.token(old.secret,step))).status,409);
 assert.equal((await update('disable',totp.token(active.secret,step))).status,403);
 await json(await update('disable',totp.token(active.secret,step+1)));
 assert.equal((await call('GET','/auth/me',undefined,'mfa')).status,401);
});
it('recovery manifest checks real table checksums, ciphertext hashes and sample decryption',async()=>{
 const {manifest}=require('../../scripts/recovery-manifest');const evidence=await manifest();assert.equal(Object.keys(evidence.tables).length,10);assert.equal(evidence.sample_decryption,'passed');assert.ok(evidence.documents.length>0);assert.notEqual(evidence.tables.users.checksum,'undefined');
 const first=evidence.documents[0],target=path.resolve(process.env.PRIVATE_UPLOAD_DIR||'private-uploads',first.id),original=fs.readFileSync(target),tampered=Buffer.from(original);tampered[0]^=1;
 try{fs.writeFileSync(target,tampered);await assert.rejects(()=>manifest());}finally{fs.writeFileSync(target,original);}
 assert.deepEqual(await manifest(),evidence);
});

it('password recovery rejects a collation-equivalent mailbox and delivers only to the stored address',async()=>{
 const canonical='owner@example.test',alias='owner@exámple.test';
 const password=await bcrypt.hash('OriginalPassword123!',4);
 await db.query("INSERT INTO users(company_id,role_id,first_name,last_name,email,password_hash,status) VALUES (?,2,'Audit','Owner',?,?,'active')",[fixture.a.company_id,canonical,password]);
 const [matched]=await db.query('SELECT email FROM users WHERE email=?',[alias]);
 assert.equal(matched[0].email,canonical);
 await json(await call('POST','/auth/forgot-password',{email:alias}));
 const {open}=require('../../src/utils/crypto');
 const jobs=async()=>{
  const [rows]=await db.query("SELECT payload FROM notification_jobs WHERE kind='email'");
  return rows.map(r=>JSON.parse(open(typeof r.payload==='string'?JSON.parse(r.payload):r.payload).toString()));
 };
 assert.ok(!(await jobs()).some(x=>x.to===alias||x.to===canonical));
 const [[account]]=await db.query('SELECT password_reset_token FROM users WHERE email=?',[canonical]);
 assert.equal(account.password_reset_token,null);
 await json(await call('POST','/auth/forgot-password',{email:canonical.toUpperCase()}));
 const queued=(await jobs()).find(x=>x.to===canonical);
 assert.ok(queued);
 const token=new URL(queued.context.resetUrl).searchParams.get('token');
 const changed='ReplacementPassword123!';
 await json(await call('POST','/auth/reset-password',{token,password:changed}));
 const result=await call('POST','/auth/login',{email:canonical,password:changed});
 assert.equal(result.status,200);
});

it('portal AI and feedback exclude private suppliers while authorized staff retain access',async()=>{
 const password=await bcrypt.hash('OriginalPassword123!',4);
 const [[role]]=await db.query("SELECT id FROM roles WHERE name='customer'");
 const [user]=await db.query("INSERT INTO users(company_id,role_id,first_name,last_name,email,password_hash,status,customer_id) VALUES (?,?,'Audit','Customer','audit-customer@test.local',?,'active',?)",[fixture.a.company_id,role.id,password,fixture.a.customer_id]);
 fixture.auditCustomer={id:user.insertId,token_version:0};
 const [vendor]=await db.query("INSERT INTO vendors (company_id,category_id,business_name,phone,city,approval_status,min_price) VALUES (?,1,'Internal Audit Supplier','123','AuditCity','approved',1098)",[fixture.a.company_id]);
 assert.equal((await call('GET','/vendors',undefined,'auditCustomer')).status,403);
 const found=await json(await call('POST','/ai/recommendations',{preferences:{city:'AuditCity'}},'auditCustomer'));
 assert.ok(!found.vendors.some(v=>v.id===vendor.insertId));
 const {reply}=await json(await call('POST','/ai/chat',{message:'recommend a supplier',preferences:{city:'AuditCity'}},'auditCustomer'));
 assert.ok(!reply.includes('Internal Audit Supplier'));
 const feedback={kind:'vendor',item_id:vendor.insertId,helpful:true};
 assert.equal((await call('POST','/ai/feedback',feedback,'auditCustomer')).status,404);
 assert.equal((await call('POST','/ai/feedback',{...feedback,item_id:fixture.vendor},'auditCustomer')).status,201);
 const shared=await json(await call('POST','/ai/recommendations',{preferences:{city:'Chennai'}},'auditCustomer'));
 assert.ok(shared.vendors.some(v=>v.id===fixture.vendor));
 fixture.a.token_version=(await db.query('SELECT token_version FROM users WHERE id=?',[fixture.a.id]))[0][0].token_version;
 const staff=await json(await call('POST','/ai/recommendations',{preferences:{city:'AuditCity'}},'a'));
 assert.ok(staff.vendors.some(v=>v.id===vendor.insertId));
 fixture.b.token_version=(await db.query('SELECT token_version FROM users WHERE id=?',[fixture.b.id]))[0][0].token_version;
 const other=await json(await call('POST','/ai/recommendations',{preferences:{city:'AuditCity'}},'b'));
 assert.ok(!other.vendors.some(v=>v.id===vendor.insertId));
});

it('repeated bad passwords cannot lock a user out of a correct sign-in',async()=>{
 const email='audit-lockout@test.local',password='CorrectPassword123!';
 const digest=await bcrypt.hash(password,4);
 await db.query("INSERT INTO users(company_id,role_id,first_name,last_name,email,password_hash,status) VALUES (?,2,'Audit','Lockout',?,?,'active')",[fixture.a.company_id,email,digest]);
 for(let n=0;n<5;n++)assert.equal((await call('POST','/auth/login',{email,password:'wrong-audit-password'})).status,401);
 assert.equal((await call('POST','/auth/login',{email,password})).status,200);
});


it('token-bearing requests omit secrets from access logs and error responses',async()=>{
 const logger=require('../../src/utils/logger'),prior=logger.http,entries=[];
 const token='synthetic-credential-marker';
 logger.http=message=>entries.push(message);
 process.env.NODE_ENV='production';
 try{
  const rsvp=await fetch(base+'/guests/rsvp-info/'+token,{headers:{Referer:'https://example.test/reset-password?token='+token}});
  assert.equal(rsvp.status,404);
  assert.equal(rsvp.headers.get('cache-control'),'no-store');
  assert.equal(rsvp.headers.get('referrer-policy'),'no-referrer');
  const missing=await fetch(base.replace('/api/v1','')+'/missing?token='+token);
  assert.equal(missing.status,404);
  assert.ok(!(await missing.text()).includes(token));
  assert.ok(entries.length>=2);
  assert.ok(entries.every(line=>!line.includes(token)));
 }finally{process.env.NODE_ENV='test';logger.http=prior;}
 for(const [file,format] of [['frontend/nginx-app.conf','safe_access'],['docker/nginx/nginx.conf','main']]){
  const config=fs.readFileSync(path.resolve(__dirname,'../../..',file),'utf8');
  const logging=config.split('\n').find(line=>line.includes('log_format '+format+' '));
  assert.ok(logging);
  assert.doesNotMatch(logging,/\$(request\b|request_uri\b|uri\b|args\b|http_referer\b)/);
 }
});
