// Run inside the backend container. Never prints credentials, message bodies or recipients.
require('dotenv').config();
const fs=require('fs/promises'),os=require('os'),path=require('path'),{execFile}=require('child_process'),{promisify}=require('util');
const result=(status,detail)=>({status,detail});
function requireEnv(keys){return keys.every(k=>!!process.env[k]);}
async function verify(check){
 if(check==='smtp'){
  if(!requireEnv(['SMTP_HOST','SMTP_USER','SMTP_PASS']))return result('blocked','Configure SMTP_HOST, SMTP_USER and SMTP_PASS.');
  const port=Number(process.env.SMTP_PORT)||587;
  const transport=require('nodemailer').createTransport({host:process.env.SMTP_HOST,port,secure:port===465,requireTLS:port!==465,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS},connectionTimeout:15000,greetingTimeout:15000,socketTimeout:20000});
  try{await transport.verify();return result('passed','SMTP connection, TLS and authentication verified; message delivery is a separate check.');}finally{transport.close();}
 }
 if(check==='email'){
  if(!requireEnv(['SMTP_HOST','SMTP_USER','SMTP_PASS','EMAIL_FROM','VERIFY_EMAIL_TO']))return result('blocked','Configure SMTP and the explicitly chosen VERIFY_EMAIL_TO address.');
  if(process.env.VERIFY_SEND_EMAIL!=='true')return result('blocked','Set VERIFY_SEND_EMAIL=true to authorize one test email to VERIFY_EMAIL_TO.');
  const port=Number(process.env.SMTP_PORT)||587,transport=require('nodemailer').createTransport({host:process.env.SMTP_HOST,port,secure:port===465,requireTLS:port!==465,auth:{user:process.env.SMTP_USER,pass:process.env.SMTP_PASS},connectionTimeout:15000,socketTimeout:20000});
  try{const info=await transport.sendMail({from:process.env.EMAIL_FROM,to:process.env.VERIFY_EMAIL_TO,subject:'EternaPlaan delivery verification',text:'This is the EternaPlaan deployment verification email. Confirm receipt in your deployment checklist.'});
   if(!info.accepted?.length)return result('failed','SMTP server did not accept the test recipient.');
   return result('pending','SMTP accepted the test email. Confirm arrival in the intended inbox; acceptance alone does not prove delivery.');
  }finally{transport.close();}
 }
 if(check==='sms'){
  if(!requireEnv(['TWILIO_ACCOUNT_SID','TWILIO_AUTH_TOKEN','TWILIO_FROM_NUMBER','VERIFY_SMS_TO']))return result('blocked','Configure Twilio and the explicitly chosen VERIFY_SMS_TO number.');
  if(process.env.VERIFY_SEND_SMS!=='true')return result('blocked','Set VERIFY_SEND_SMS=true to authorize one test SMS; provider charges may apply.');
  const client=require('twilio')(process.env.TWILIO_ACCOUNT_SID,process.env.TWILIO_AUTH_TOKEN),message=await client.messages.create({from:process.env.TWILIO_FROM_NUMBER,to:process.env.VERIFY_SMS_TO,body:'EternaPlaan deployment verification message.'});
  let status=message.status;
  for(let i=0;i<6&&!['delivered','undelivered','failed'].includes(status);i++){await new Promise(r=>setTimeout(r,3000));status=(await client.messages(message.sid).fetch()).status;}
  return result(status==='delivered'?'passed':['undelivered','failed'].includes(status)?'failed':'pending',`Provider delivery state: ${status}. Confirm receipt on the intended handset.`);
 }
 if(check==='ai'){
  if(!requireEnv(['OPENAI_API_KEY','OPENAI_MODEL']))return result('blocked','Configure OPENAI_API_KEY and OPENAI_MODEL, or leave conversational AI disabled.');
  if(process.env.VERIFY_AI!=='true')return result('blocked','Set VERIFY_AI=true to authorize one small billable AI smoke request.');
  const answer=await require('../src/services/assistant').answer({message:'Give one short event-planning tip.',history:[],context:{venues:[],vendors:[]},useAI:true});
  return result(answer.mode==='ai'&&answer.reply?'passed':'failed',answer.mode==='ai'?'Real conversational AI returned text. Accuracy/safety evaluation remains a separate review.':'The request used local fallback; external AI was not verified.');
 }
 if(check==='scanner'){
  let temp;
  try{temp=await fs.mkdtemp(path.join(os.tmpdir(),'ep-verify-scan-'));const clean=path.join(temp,'clean.pdf'),sample=path.join(temp,'scanner-test');
   await fs.writeFile(clean,'%PDF-1.4\nEternaPlaan clean scanner test\n',{mode:0o600});
   // Standard harmless EICAR antivirus test string, constructed only in the temporary test file.
   const test='X5O!P%@AP[4\\PZX54(P^)7CC)7}'+ '$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*';await fs.writeFile(sample,test,{mode:0o600});
   const scan=file=>promisify(execFile)('clamdscan',['--no-summary','--stream',file],{timeout:30000});
   await scan(clean);let detected=false;try{await scan(sample);}catch(e){if(e.code===1)detected=true;else throw e;}
   return result(detected?'passed':'failed',detected?'Scanner accepted clean content and detected the standard antivirus test sample. This checks the scanning engine; authenticated upload acceptance/rejection must also be checked.':'Scanner did not detect the antivirus test sample.');
  }finally{if(temp)await fs.rm(temp,{recursive:true,force:true});}
 }
 if(check==='stripe-test'){
  if(!/^sk_test_|^rk_test_/.test(process.env.STRIPE_SECRET_KEY||''))return result('blocked','A Stripe TEST secret/restricted key is required; this check refuses live keys.');
  if(process.env.VERIFY_STRIPE_TEST!=='true')return result('blocked','Set VERIFY_STRIPE_TEST=true to authorize a provider sandbox payment and immediate refund.');
  const stripe=new (require('stripe'))(process.env.STRIPE_SECRET_KEY,{timeout:20000,maxNetworkRetries:1}),run=require('crypto').randomUUID();
  const payment=await stripe.paymentIntents.create({amount:10000,currency:'inr',payment_method:'pm_card_visa',payment_method_types:['card'],confirm:true,description:'EternaPlaan sandbox deployment verification'},{idempotencyKey:`ep-verification-payment-${run}`});
  if(payment.livemode||payment.status!=='succeeded')return result('failed','Sandbox payment was not confirmed as succeeded. Inspect the test-mode provider dashboard.');
  const refund=await stripe.refunds.create({payment_intent:payment.id,amount:10000},{idempotencyKey:`ep-verification-refund-${run}`});
  return result(refund.status==='succeeded'?'passed':['failed','canceled'].includes(refund.status)?'failed':'pending',refund.status==='succeeded'?'Provider sandbox payment and refund succeeded. App Checkout, signed delivery and local ledger linkage still need their separate check.':`Sandbox refund state: ${refund.status}. Inspect the provider test dashboard.`);
 }
 if(check==='webhook-ledger'){
  if(!/^sk_test_|^rk_test_/.test(process.env.STRIPE_SECRET_KEY||''))return result('blocked','Use a Stripe test key for sandbox webhook proof.');
  if(!requireEnv(['VERIFY_STRIPE_EVENT_ID','VERIFY_ORDER_ID']))return result('blocked','Complete app test Checkout, then supply VERIFY_STRIPE_EVENT_ID and VERIFY_ORDER_ID from that operation.');
  const stripe=new (require('stripe'))(process.env.STRIPE_SECRET_KEY,{timeout:15000}),event=await stripe.events.retrieve(process.env.VERIFY_STRIPE_EVENT_ID),{sequelize}=require('../src/config/database');
  try{
   if(event.livemode||!['checkout.session.completed','checkout.session.async_payment_succeeded'].includes(event.type))return result('failed','Expected a sandbox Checkout payment event.');
   const [order]=await sequelize.query('SELECT * FROM billing_orders WHERE id=?',{replacements:[process.env.VERIFY_ORDER_ID],type:sequelize.QueryTypes.SELECT});
   const [recorded]=await sequelize.query('SELECT id FROM billing_webhook_events WHERE id=?',{replacements:[event.id],type:sequelize.QueryTypes.SELECT});
   if(!order||!recorded||event.data.object.id!==order.session_id||order.state!=='paid')return result('pending','Matching provider event and paid local order are not both recorded yet.');
   const [ledger]=await sequelize.query("SELECT COUNT(*) AS entries,SUM(amount_minor) AS captured FROM billing_ledger WHERE order_id=? AND kind='capture'",{replacements:[order.id],type:sequelize.QueryTypes.SELECT});
   return result(Number(ledger.entries)===1&&Number(ledger.captured)===Number(order.amount_minor)?'passed':'failed','Checked genuine provider event identity, matching paid local order and a single capture ledger entry. Confirm delivery details in the provider webhook dashboard as well.');
  }finally{await sequelize.close();}
 }
 return result('failed','Unknown service check.');
}
module.exports={verify};
if(require.main===module)verify(process.argv[2]).then(r=>{console.log(JSON.stringify(r));if(r.status!=='passed')process.exitCode=2;}).catch(()=>{console.log(JSON.stringify(result('failed','Service check failed. Inspect provider configuration/dashboard; credentials and raw errors are omitted from this report.')));process.exitCode=1;});
