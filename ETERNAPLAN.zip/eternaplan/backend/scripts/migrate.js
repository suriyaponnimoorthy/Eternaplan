require('dotenv').config();
const mysql=require('mysql2/promise'),fs=require('fs'),path=require('path'),crypto=require('crypto');
async function migrate(config){
 const db=await mysql.createConnection(config);
 try{
 await db.query('CREATE TABLE IF NOT EXISTS schema_migrations (name VARCHAR(200) PRIMARY KEY, checksum CHAR(64) NOT NULL)');
 await db.query('CREATE TABLE IF NOT EXISTS schema_migration_steps (name VARCHAR(220) PRIMARY KEY)');
 const directory=path.resolve(__dirname,'../../database/migrations');
 for(const name of fs.readdirSync(directory).filter(x=>x.endsWith('.sql')).sort()){
  const sql=fs.readFileSync(path.join(directory,name),'utf8'),checksum=crypto.createHash('sha256').update(sql).digest('hex');
  const [done]=await db.query('SELECT checksum FROM schema_migrations WHERE name=?',[name]);if(done.length){if(done[0].checksum!==checksum)throw Error('Applied migration was modified: '+name);continue;}
  let index=0;for(const statement of sql.split(';').map(x=>x.trim()).filter(Boolean)){
   const step=`${name}:${index++}`,[existing]=await db.query('SELECT name FROM schema_migration_steps WHERE name=?',[step]);if(existing.length)continue;
   try{await db.query(statement);}catch(e){if(!['ER_DUP_FIELDNAME','ER_DUP_KEYNAME','ER_TABLE_EXISTS_ERROR','ER_FK_DUP_NAME'].includes(e.code))throw e;}
   await db.query('INSERT INTO schema_migration_steps (name) VALUES (?)',[step]);
  }
  await db.query('INSERT INTO schema_migrations (name,checksum) VALUES (?,?)',[name,checksum]);
 }
 }finally{await db.end();}
}
module.exports={migrate};
if(require.main===module)migrate({host:process.env.DB_HOST||'127.0.0.1',port:Number(process.env.DB_PORT)||3306,user:process.env.DB_MIGRATION_USER||process.env.DB_USER,password:process.env.DB_MIGRATION_PASSWORD||process.env.DB_PASSWORD,database:process.env.DB_NAME}).then(()=>console.log('Migrations complete.')).catch(e=>{console.error(e.message);process.exit(1);});
