// Operator-only backup/restore evidence. Contains no plaintext records or credentials.
require('dotenv').config();
const fs=require('fs/promises'),path=require('path'),crypto=require('crypto'),{sequelize}=require('../src/config/database'),{open}=require('../src/utils/crypto');
async function manifest(){
 const tables=['companies','users','customers','events','bookings','guests','invoices','payments','billing_ledger','private_documents'];
 const result={tables:{},documents:[],sample_decryption:'no_private_documents'};
 for(const table of tables){const [count]=await sequelize.query(`SELECT COUNT(*) AS total FROM ${table}`,{type:sequelize.QueryTypes.SELECT});const [checksum]=await sequelize.query(`CHECKSUM TABLE ${table} EXTENDED`,{type:sequelize.QueryTypes.SELECT});result.tables[table]={rows:Number(count.total),checksum:String(checksum.Checksum)};}
 const docs=await sequelize.query('SELECT id,nonce,auth_tag FROM private_documents ORDER BY id',{type:sequelize.QueryTypes.SELECT});
 for(const doc of docs){const bytes=await fs.readFile(path.join(path.resolve(process.env.PRIVATE_UPLOAD_DIR||'private-uploads'),doc.id));result.documents.push({id:doc.id,sha256:crypto.createHash('sha256').update(bytes).digest('hex')});}
 if(docs.length){const first=docs[0],bytes=await fs.readFile(path.join(path.resolve(process.env.PRIVATE_UPLOAD_DIR||'private-uploads'),first.id));open({nonce:first.nonce,tag:first.auth_tag,data:bytes.toString('base64')});result.sample_decryption='passed';}
 return result;
}
module.exports={manifest};
if(require.main===module)(async()=>{
 const actual=await manifest();
 if(process.argv[2]==='--compare'){
  let input='';for await(const chunk of process.stdin)input+=chunk;
  if(JSON.stringify(actual)!==JSON.stringify(JSON.parse(input)))throw Error('Restored data did not match the backup manifest');
  console.log(JSON.stringify({status:'passed',tables_verified:Object.keys(actual.tables).length,private_files_verified:actual.documents.length,sample_decryption:actual.sample_decryption}));
 }else console.log(JSON.stringify(actual));
})().catch(()=>{console.error('Recovery manifest generation/comparison failed; inspect the isolated deployment.');process.exitCode=1;}).finally(()=>sequelize.close());
