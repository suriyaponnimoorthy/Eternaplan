// Operator-only recovery. Run after independently verifying the account holder.
require('dotenv').config();
const {sequelize}=require('../src/config/database');
(async()=>{
 const id=process.env.RECOVER_MFA_USER_ID;
 if(!/^\d+$/.test(id||'')||process.env.RECOVER_MFA_CONFIRM!=='identity-verified')throw Error('Set RECOVER_MFA_USER_ID and RECOVER_MFA_CONFIRM=identity-verified after identity verification.');
 await sequelize.transaction(async transaction=>{
 const [user]=await sequelize.query('SELECT id,company_id FROM users WHERE id=? FOR UPDATE',{replacements:[id],transaction,type:sequelize.QueryTypes.SELECT});if(!user)throw Error('User not found');
 await sequelize.query('UPDATE users SET mfa_secret=NULL,mfa_pending=NULL,mfa_pending_expires_at=NULL,mfa_pending_version=NULL,mfa_last_step=0,refresh_token=NULL,token_version=token_version+1 WHERE id=?',{replacements:[id],transaction});
 await sequelize.query("INSERT INTO audit_logs (company_id,action,entity_type,entity_id) VALUES (?,'operator_mfa_recovery','user',?)",{replacements:[user.company_id,user.id],transaction});
 });console.log('MFA cleared and sessions revoked. The user must sign in and enroll again.');
})().catch(e=>{console.error(e.message);process.exitCode=1;}).finally(()=>sequelize.close());
