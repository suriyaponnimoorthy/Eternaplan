require('dotenv').config();
const {sequelize}=require('../src/config/database');
(async()=>{
 const [state]=await sequelize.query("SELECT SUM(state='failed') AS failed,SUM(state IN ('pending','sending') AND created_at<DATE_SUB(NOW(),INTERVAL 10 MINUTE)) AS stale FROM notification_jobs",{type:sequelize.QueryTypes.SELECT});
 if(Number(state.failed)||Number(state.stale))throw Error('Notification queue has failed or overdue jobs. Inspect provider configuration and job state.');
 console.log('No failed or overdue notification jobs.');
})().catch(e=>{console.error(e.message);process.exitCode=1;}).finally(()=>sequelize.close());
