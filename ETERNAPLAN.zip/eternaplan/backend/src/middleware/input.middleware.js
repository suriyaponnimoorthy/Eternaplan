const {body,param,query}=require('express-validator');const {validateRequest}=require('./validate.middleware');
const money=k=>body(k).optional({nullable:true}).matches(/^\d{1,9}(\.\d{1,2})?$/).withMessage('Use a non-negative amount with at most two decimals');
const date=k=>body(k).optional({nullable:true}).isISO8601({strict:true}).matches(/^\d{4}-\d{2}-\d{2}$/);
exports.common=[...['budget_total','quoted_price','agreed_price','advance_amount','amount','subtotal','min_price','max_price','discount_value'].map(money),...['event_date','booking_date','end_date','due_date','invoice_date','expense_date','payment_date'].map(date),
 body('tax_rate').optional().isFloat({min:0,max:100}),body('guest_count_estimate').optional().isInt({min:0,max:1000000}),body('guest_count_actual').optional().isInt({min:0,max:1000000}),
 body('status').optional().isString().isLength({max:30}),body('note').optional().isString().trim().isLength({min:1,max:5000}),
 body('first_name').optional().isString().trim().isLength({min:1,max:100}),body('last_name').optional().isString().trim().isLength({max:100}),body('event_name').optional().isString().trim().isLength({min:1,max:200}),
 body('phone').optional().isString().isLength({max:30}),body('business_name').optional().isString().trim().isLength({min:1,max:200}),
 body('meal_preference').optional().isIn(['veg','non_veg','vegan','jain','no_preference']),
 body('title').optional().isString().trim().isLength({min:1,max:255}),body('email').optional({checkFalsy:true}).isEmail(),
 ...['customer_id','event_id','vendor_id','venue_id','assigned_to','package_id','invoice_id','booking_id'].map(k=>body(k).optional({nullable:true}).isInt({min:1})),validateRequest];
exports.required=(...keys)=>[...keys.map(k=>body(k).exists({checkFalsy:true})),validateRequest];
