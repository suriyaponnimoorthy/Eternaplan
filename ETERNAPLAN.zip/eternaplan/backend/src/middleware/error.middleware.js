// error.middleware.js
const logger = require('../utils/logger');

exports.errorHandler = (err, req, res, next) => {
  if(process.env.NODE_ENV==='test' && process.env.DEBUG_TEST_ERRORS==='1') console.error(err.message);
  let { statusCode = 500, message, errors } = err;
  if (process.env.NODE_ENV === 'development') logger.error(err.stack);
  if (err.name === 'SequelizeValidationError')    { statusCode = 422; message = err.errors?.map(e=>e.message).join(', '); }
  if (err.name === 'SequelizeUniqueConstraintError') { statusCode = 409; message = 'Duplicate entry. Record already exists.'; }
  if (err.code === 'ER_DUP_ENTRY')               { statusCode = 409; message = 'Duplicate entry.'; }
  if(statusCode>=500 && process.env.NODE_ENV!=='development') message='The request could not be completed.';
  if(err.code==='LIMIT_FILE_SIZE'){statusCode=413;message='Maximum file size is 5 MB.';}
  res.status(statusCode).json({ success: false, message, ...(errors && { errors }), ...(process.env.NODE_ENV === 'development' && { stack: err.stack }) });
};

exports.notFoundHandler = (req, res) => {
  res.status(404).json({ success: false, message: 'Route not found.' });
};
