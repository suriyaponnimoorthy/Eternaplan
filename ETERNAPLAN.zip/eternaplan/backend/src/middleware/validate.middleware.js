// middleware/validate.middleware.js
const { validationResult } = require('express-validator');
const AppError = require('../utils/AppError');

exports.validateRequest = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const fields = errors.array().map(({value, ...error}) => error);
    const messages = fields.map(e => `${e.path}: ${e.msg}`);
    return next(new AppError(`Validation failed: ${messages.join('. ')}`, 422, fields));
  }
  next();
};
