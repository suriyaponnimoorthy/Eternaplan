const { sequelize } = require('../config/database');
const AppError = require('../utils/AppError');
const select = (sql,replacements) => sequelize.query(sql,{replacements,type:sequelize.QueryTypes.SELECT});
const id = v => /^\d+$/.test(String(v)) && Number.isSafeInteger(Number(v)) && Number(v)>0;
async function own(table,value,company,shared=false) {
  if (!id(value)) throw new AppError('Invalid resource identifier.',422);
  const [row]=await select(`SELECT * FROM ${table} WHERE id=? AND (company_id=?${shared?' OR company_id IS NULL':''})`,[value,company]);
  if(!row) throw new AppError('Resource not found.',404);return row;
}
exports.own=own;
exports.staffAccess = async(req,res,next)=>{
 try {
  if(!req.user?.company_id || !['super_admin','admin','event_manager'].includes(req.user.role)) throw new AppError('This workspace is for company staff. Use your personal portal.',403);
  const path=req.path, write=!['GET','HEAD'].includes(req.method);
  // Per-route authorization below is authoritative; this layer validates membership and references.
  for(const k of ['page','limit']) if(req.query[k]!==undefined){if(!id(req.query[k]))throw new AppError('Invalid pagination.',422);req.query[k]=Math.min(Number(req.query[k]),k==='limit'?100:100000);}
  const match=path.match(/^\/(events|customers|vendors|bookings|guests)\/(\d+)(?:\/|$)/);
  if(match){const [,table,value]=match;
   if(table==='guests') {const [g]=await select('SELECT g.id,g.event_id FROM guests g JOIN events e ON e.id=g.event_id WHERE g.id=? AND e.company_id=?',[value,req.user.company_id]);if(!g)throw new AppError('Resource not found.',404);}
   else await own(table,value,req.user.company_id,table==='vendors'&&!write);
   const task=path.match(/^\/events\/(\d+)\/tasks\/(\d+)$/);
   if(task){const [row]=await select('SELECT id FROM event_tasks WHERE id=? AND event_id=?',[task[2],task[1]]);if(!row)throw new AppError('Task not found.',404);}
  }
  const financial=path.match(/^\/finance\/(invoices|expenses)\/(\d+)$/);if(financial)await own(financial[1],financial[2],req.user.company_id);
  if(path==='/guests'&&req.method==='GET'&&!req.query.event_id)throw new AppError('event_id is required.',422);
  const refs={event_id:'events',customer_id:'customers',vendor_id:'vendors',venue_id:'venues',assigned_to:'users',category_id:path.startsWith('/vendors')?'vendor_categories':'event_categories'};
  const linked={};
  for(const [key,table] of Object.entries(refs)){
   const value=req.body?.[key]??req.query[key];if(value===undefined||value===null||value==='')continue;
   if(table==='vendor_categories'){if(!id(value))throw new AppError('Invalid category.',422);const [c]=await select('SELECT id FROM vendor_categories WHERE id=? AND is_active=1',[value]);if(!c)throw new AppError('Category not found.',404);}
   else linked[key]=await own(table,value,req.user.company_id,['vendors','venues','event_categories'].includes(table));
  }
  if(linked.event_id && linked.customer_id && linked.event_id.customer_id!==linked.customer_id.id)throw new AppError('Customer does not belong to this event.',422);
  if(req.body?.package_id){const [p]=await select('SELECT id FROM vendor_packages WHERE id=? AND vendor_id=? AND is_active=1',[req.body.package_id,req.body.vendor_id||0]);if(!p)throw new AppError('Package does not belong to supplier.',422);}
  if(req.body?.group_id){const [g]=await select('SELECT id FROM guest_groups WHERE id=? AND event_id=?',[req.body.group_id,req.body.event_id||0]);if(!g)throw new AppError('Guest group not found.',404);}
  if(req.body?.parent_task_id){const eid=path.match(/^\/events\/(\d+)\/tasks/)?.[1];const [t]=await select('SELECT id FROM event_tasks WHERE id=? AND event_id=?',[req.body.parent_task_id,eid||0]);if(!t)throw new AppError('Parent task not found.',404);}
  if(req.body?.invoice_id){const invoice=await own('invoices',req.body.invoice_id,req.user.company_id);if(req.body.customer_id&&Number(req.body.customer_id)!==invoice.customer_id)throw new AppError('Invoice/customer mismatch.',422);}
  if(req.body?.booking_id)await own('bookings',req.body.booking_id,req.user.company_id);
  next();
 }catch(e){next(e);}
};
