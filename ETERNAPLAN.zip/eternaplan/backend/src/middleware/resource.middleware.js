const {sequelize}=require('../config/database');
const AppError=require('../utils/AppError');
const select=(sql,replacements)=>sequelize.query(sql,{replacements,type:sequelize.QueryTypes.SELECT});
const numericId=value=>/^[1-9]\d*$/.test(String(value))&&Number.isSafeInteger(Number(value))&&Number(value)<=4294967295;
exports.canonicalPath=(req,res,next)=>{
 // IDs and invitation tokens in this API need no percent-encoded path characters.
 // Reject ambiguity before matching a route; query-string encoding is unaffected.
 if(/%|\\|\/\//.test(req.path))return next(new AppError('Use the canonical API path.',400));
 next();
};
exports.resource=(table,{sharedRead=false}={})=>async(req,res,next)=>{
 try{
  if(!numericId(req.params.id))throw new AppError('Resource not found.',404);
  const company=req.user.company_id,id=Number(req.params.id);
  const sql=table==='guests'
   ? 'SELECT g.id,g.event_id FROM guests g JOIN events e ON e.id=g.event_id WHERE g.id=? AND e.company_id=?'
   : `SELECT id FROM ${table} WHERE id=? AND (company_id=?${sharedRead&&['GET','HEAD'].includes(req.method)?' OR company_id IS NULL':''})`;
  const [row]=await select(sql,[id,company]);if(!row)throw new AppError('Resource not found.',404);
  next();
 }catch(e){next(e);}
};
exports.task=async(req,res,next)=>{
 try{
  if(!numericId(req.params.taskId))throw new AppError('Task not found.',404);
  const [row]=await select('SELECT t.id FROM event_tasks t JOIN events e ON e.id=t.event_id WHERE t.id=? AND t.event_id=? AND e.company_id=?',[Number(req.params.taskId),Number(req.params.id),req.user.company_id]);
  if(!row)throw new AppError('Task not found.',404);next();
 }catch(e){next(e);}
};
exports.numericId=numericId;
