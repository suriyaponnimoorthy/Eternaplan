const {sequelize}=require('../config/database');const AppError=require('../utils/AppError');
exports.quota=(name,max,windowMs,keyFn)=>async(req,res,next)=>{
 try{const key=`${name}:${keyFn(req)}:${Math.floor(Date.now()/windowMs)}`;
 const hits=await sequelize.transaction(async t=>{
 await sequelize.query('INSERT INTO request_quotas (quota_key,hits,expires_at) VALUES (?,1,DATE_ADD(NOW(),INTERVAL ? SECOND)) ON DUPLICATE KEY UPDATE hits=hits+1',{replacements:[key,Math.ceil(windowMs/1000)],transaction:t});
 const [q]=await sequelize.query('SELECT hits FROM request_quotas WHERE quota_key=?',{replacements:[key],type:sequelize.QueryTypes.SELECT,transaction:t});return q.hits;
 });if(hits>max){res.set('Retry-After',String(Math.ceil(windowMs/1000)));throw new AppError('Usage limit reached. Please try again later.',429);}next();
 }catch(e){next(e);}
};
