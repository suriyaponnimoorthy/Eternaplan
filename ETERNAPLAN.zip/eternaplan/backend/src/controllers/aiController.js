const { sequelize } = require('../config/database');
const { rankCandidates } = require('../services/recommendations');
const { answer } = require('../services/assistant');
const AppError = require('../utils/AppError');
const select = (sql, replacements) => sequelize.query(sql, { replacements, type: sequelize.QueryTypes.SELECT });
const isStaff=user=>['super_admin','admin','event_manager'].includes(user.role);
async function catalog(user, p) {
  const companyId=user.company_id;
  if (!companyId) throw new AppError('A company account is required.', 403);
  const catalogScope=isStaff(user)?'(v.company_id=:companyId OR v.company_id IS NULL)':'v.company_id IS NULL';
  const cityClause = p.city ? ' AND v.city_normalized=LOWER(TRIM(:city))' : '';
  const replacements = { companyId, city: p.city || '', date: p.date || null, guests: Number(p.guests || 0), budget: Number(p.budget || 0), category: Number(p.category_id || 0) };
  const venues = await select(`SELECT v.id,v.name,v.city,v.capacity_max,v.base_price,v.price_per_day,v.rating,v.total_reviews
    FROM venues v WHERE ${catalogScope} AND v.is_available=1 ${cityClause}
    AND (:guests = 0 OR v.capacity_max>=:guests)
    AND (:budget = 0 OR COALESCE(v.price_per_day,v.base_price,0)<=:budget)
    AND (:date IS NULL OR (NOT EXISTS (SELECT 1 FROM venue_bookings b WHERE b.venue_id=v.id AND b.booked_date=:date AND b.status IN ('reserved','confirmed'))
      AND NOT EXISTS (SELECT 1 FROM bookings b WHERE b.venue_id=v.id AND b.booking_date<=:date AND COALESCE(b.end_date,b.booking_date)>=:date AND b.status<>'cancelled' AND b.approval_status<>'rejected')
      AND NOT EXISTS (SELECT 1 FROM events e WHERE e.venue_id=v.id AND e.event_date<=:date AND COALESCE(e.end_date,e.event_date)>=:date AND e.status<>'cancelled'))) ORDER BY v.rating DESC,v.total_reviews DESC,v.id LIMIT 500`, replacements);
  const vendors = await select(`SELECT v.id,v.business_name,v.city,v.min_price,v.max_price,v.rating,v.total_reviews,v.category_id,c.name AS category
    FROM vendors v JOIN vendor_categories c ON c.id=v.category_id
    WHERE ${catalogScope} AND v.approval_status='approved' AND c.is_active=1 ${cityClause}
    AND (:category = 0 OR v.category_id=:category) AND (:budget = 0 OR COALESCE(v.min_price,0)<=:budget)
    AND (:date IS NULL OR NOT EXISTS (SELECT 1 FROM bookings b WHERE b.vendor_id=v.id AND b.booking_date<=:date AND COALESCE(b.end_date,b.booking_date)>=:date AND b.status<>'cancelled' AND b.approval_status<>'rejected')) ORDER BY v.rating DESC,v.total_reviews DESC,v.id LIMIT 500`, replacements);
  return { venues: rankCandidates(venues,p,'venue'), vendors: rankCandidates(vendors,p,'vendor'), method: 'content-based',
    note: 'Search ranks up to 500 filtered candidates per type. Fit points reflect explicit preferences and review evidence; they are not ML probabilities. Date conflicts conservatively exclude the entire day. Confirm final availability and quotes.' };
}
exports.recommendations = async (req,res,next) => {
  try { res.json({ success:true, data: await catalog(req.user, req.body.preferences || {}) }); } catch(e) { next(e); }
};
exports.chat = async (req,res,next) => {
  try {
    const context = await catalog(req.user, req.body.preferences || {});
    const data = await answer({ message:req.body.message, history:(req.body.history || []).map(({role,content})=>({role,content})), context, useAI:req.body.use_ai === true });
    res.json({ success:true, data });
  } catch(e) { next(e); }
};
exports.catalog = catalog;
exports.isStaff = isStaff;
