const {sequelize}=require('../config/database');
const select=(sql,replacements)=>sequelize.query(sql,{replacements,type:sequelize.QueryTypes.SELECT});
exports.getOverview=async(req,res,next)=>{try{
 const c=req.user.company_id,year=Number(req.query.year)||new Date().getFullYear();
 const events=await select('SELECT status,COUNT(*) AS count FROM events WHERE company_id=? AND YEAR(event_date)=? GROUP BY status',[c,year]);
 const [money]=await select("SELECT COALESCE(SUM(amount),0) AS total_revenue,COALESCE(SUM(IF(MONTH(payment_date)=MONTH(CURDATE()) AND YEAR(payment_date)=YEAR(CURDATE()),amount,0)),0) AS revenue_this_month FROM payments WHERE company_id=? AND status='completed' AND YEAR(payment_date)=?",[c,year]);
 const [customers]=await select('SELECT COUNT(*) AS total_customers,SUM(YEAR(created_at)=?) AS new_customers FROM customers WHERE company_id=?',[year,c]);
 const [expenses]=await select("SELECT COALESCE(SUM(amount),0) AS total_expenses FROM expenses WHERE company_id=? AND status<>'rejected' AND YEAR(expense_date)=?",[c,year]);
 const months=await select("SELECT DATE_FORMAT(payment_date,'%Y-%m') AS month_key,DATE_FORMAT(MIN(payment_date),'%b %Y') AS month_label,SUM(amount) AS revenue FROM payments WHERE company_id=? AND status='completed' AND YEAR(payment_date)=? GROUP BY DATE_FORMAT(payment_date,'%Y-%m') ORDER BY month_key",[c,year]);
 const costs=await select("SELECT DATE_FORMAT(expense_date,'%Y-%m') AS month_key,SUM(amount) AS expenses FROM expenses WHERE company_id=? AND status<>'rejected' AND YEAR(expense_date)=? GROUP BY DATE_FORMAT(expense_date,'%Y-%m')",[c,year]);
 const keys=[...new Set([...months,...costs].map(x=>x.month_key))].sort();
 const monthly_revenue=keys.map(key=>({month_key:key,month_label:months.find(x=>x.month_key===key)?.month_label||key,revenue:Number(months.find(x=>x.month_key===key)?.revenue||0),expenses:Number(costs.find(x=>x.month_key===key)?.expenses||0)}));
 const upcoming=await select("SELECT id,event_name,event_date,status FROM events WHERE company_id=? AND event_date>=CURDATE() AND status NOT IN ('completed','cancelled') ORDER BY event_date LIMIT 10",[c]);
 const [task]=await select("SELECT COUNT(*) AS total,SUM(t.status='completed') AS completed,SUM(t.status='pending') AS pending,SUM(t.status='in_progress') AS in_progress FROM event_tasks t JOIN events e ON e.id=t.event_id WHERE e.company_id=?",[c]);
 res.json({success:true,data:{kpi:{...money,...customers,...expenses,total_events:events.reduce((s,x)=>s+Number(x.count),0),completed_events:Number(events.find(x=>x.status==='completed')?.count||0),upcoming_events:upcoming.length},monthly_revenue,upcoming_events:upcoming,event_status:events,task_summary:task}});
}catch(e){next(e);}};
exports.getMonthlyReport=async(req,res,next)=>{try{
 const c=req.user.company_id,m=Number(req.query.month)||new Date().getMonth()+1,y=Number(req.query.year)||new Date().getFullYear();
 const events=await select("SELECT e.id,e.event_code,e.event_name,e.event_date,e.status,e.guest_count_actual,(SELECT COALESCE(SUM(p.amount),0) FROM payments p JOIN invoices i ON p.invoice_id=i.id WHERE i.event_id=e.id AND p.status='completed') AS received,(SELECT COALESCE(SUM(ex.amount),0) FROM expenses ex WHERE ex.event_id=e.id AND ex.status<>'rejected') AS expenses FROM events e WHERE e.company_id=? AND MONTH(e.event_date)=? AND YEAR(e.event_date)=? ORDER BY e.event_date",[c,m,y]);
 res.json({success:true,data:{events,summary:{total_events:events.length,total_guests:events.reduce((a,e)=>a+Number(e.guest_count_actual||0),0),total_revenue:events.reduce((a,e)=>a+Number(e.received),0),total_expenses:events.reduce((a,e)=>a+Number(e.expenses),0)}}});
}catch(e){next(e);}};
