const bcrypt=require('bcryptjs'),crypto=require('crypto');
const {sequelize}=require('../config/database');
const {generateTokens,verifyRefreshToken}=require('../utils/jwt');
const {hash}=require('../utils/crypto');
const {enqueue}=require('../services/notifications');
const AppError=require('../utils/AppError');
const select=(sql,replacements,transaction)=>sequelize.query(sql,{replacements,transaction,type:sequelize.QueryTypes.SELECT});
const run=(sql,replacements,transaction)=>sequelize.query(sql,{replacements,transaction});
const cookie=(res,token)=>res.cookie('refreshToken',token,{httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'strict',maxAge:7*86400000,path:'/api/v1/auth'});
const parse=v=>typeof v==='string'?JSON.parse(v):v;
const emailKey=email=>email.normalize('NFC').toLowerCase();
const matchesEmail=(user,email)=>user && emailKey(user.email)===emailKey(email);
// Keep password verification work comparable for unknown accounts.
const dummyHash='$2a$12$ch3ISLydK4VdsebFj9Srqu6XLZ6OJ0Z6IlRZA3vaDbA1q.nY6bZhK';
exports.register=async(req,res,next)=>{
 try{
  const {first_name,last_name,email,phone,password,company_name}=req.body;
  if(!company_name?.trim())throw new AppError('Company name is required. Customers and staff must join using an invitation.',422);
  const otp=crypto.randomInt(100000,1000000).toString(),passwordHash=await bcrypt.hash(password,12);
  await sequelize.transaction(async t=>{
   const [existing]=await select('SELECT id FROM users WHERE email=?',[email],t);if(existing)throw new AppError('Email already registered.',409);
   const [companyId]=await sequelize.query('INSERT INTO companies (name,slug,email) VALUES (?,?,?)',{replacements:[company_name,crypto.randomUUID(),email],transaction:t,type:sequelize.QueryTypes.INSERT});
   await run("INSERT INTO users (company_id,role_id,first_name,last_name,email,phone,password_hash,otp_code,otp_expires_at,status) SELECT ?,id,?,?,?,?,?,?,DATE_ADD(NOW(),INTERVAL 10 MINUTE),'pending' FROM roles WHERE name='admin'",[companyId,first_name,last_name,email,phone,passwordHash,hash(otp)],t);
   await enqueue('email',{to:email,subject:'Verify your EternaPlaan account',template:'otp',context:{name:first_name,otp}},t);
  });res.status(201).json({success:true,message:'Account created. A verification email is queued.',data:{email}});
 }catch(e){next(e);}
};
exports.verifyOTP=async(req,res,next)=>{
 try{
  await sequelize.transaction(async t=>{
   const [u]=await select('SELECT *,otp_expires_at>NOW() AS otp_valid FROM users WHERE email=? FOR UPDATE',[req.body.email],t);
   if(!matchesEmail(u,req.body.email)||!u.otp_code||hash(req.body.otp)!==u.otp_code||!Number(u.otp_valid)||u.status!=='pending')throw new AppError('Invalid or expired code.',400);
   await run("UPDATE users SET status='active',email_verified=1,otp_code=NULL,otp_expires_at=NULL WHERE id=?",[u.id],t);
  });res.json({success:true,message:'Email verified. You can sign in.'});
 }catch(e){next(e);}
};
exports.resendOTP=async(req,res,next)=>{
 try{
  await sequelize.transaction(async t=>{
   const [u]=await select("SELECT id,first_name,email FROM users WHERE email=? AND status='pending' FOR UPDATE",[req.body.email],t);if(!matchesEmail(u,req.body.email))return;
   const otp=crypto.randomInt(100000,1000000).toString();await run('UPDATE users SET otp_code=?,otp_expires_at=DATE_ADD(NOW(),INTERVAL 10 MINUTE) WHERE id=?',[hash(otp),u.id],t);
   await enqueue('email',{to:u.email,subject:'Your verification code',template:'otp',context:{name:u.first_name,otp}},t);
  });res.json({success:true,message:'If verification is pending, a new code has been queued.'});
 }catch(e){next(e);}
};
exports.login=async(req,res,next)=>{
 try{
  const [u]=await select('SELECT u.*,r.name AS role_name,r.permissions,c.name AS company_name FROM users u JOIN roles r ON r.id=u.role_id LEFT JOIN companies c ON c.id=u.company_id WHERE u.email=?',[req.body.email]);
  const matched=matchesEmail(u,req.body.email);
  const validPassword=await bcrypt.compare(req.body.password,matched?u.password_hash:dummyHash);
  if(!matched||!validPassword)throw new AppError('Invalid credentials.',401);
  if(u.status!=='active')throw new AppError('Account is not active. Verify your email or contact your administrator.',403);
  if(u.mfa_secret){
   const {open}=require('../utils/crypto'),totp=require('../utils/totp');
   const secret=open(typeof u.mfa_secret==='string'?JSON.parse(u.mfa_secret):u.mfa_secret).toString(),step=totp.verify(secret,req.body.totp,Number(u.mfa_last_step));
   if(!step)throw new AppError('A valid authenticator code is required.',401);
   const [result]=await run('UPDATE users SET mfa_last_step=? WHERE id=? AND token_version=? AND mfa_last_step< ?',[step,u.id,u.token_version,step]);if(!result.affectedRows)throw new AppError('Authenticator code already used.',401);
  }
  const tokens=generateTokens(u);
  const [updated]=await run("UPDATE users SET refresh_token=?,last_login=NOW() WHERE id=? AND token_version=? AND status='active'",[hash(tokens.refreshToken),u.id,u.token_version]);
  if(!updated.affectedRows)throw new AppError('Invalid credentials.',401);
  cookie(res,tokens.refreshToken);
  res.json({success:true,data:{token:tokens.accessToken,user:{id:u.id,name:`${u.first_name} ${u.last_name}`,email:u.email,role:u.role_name,permissions:parse(u.permissions)||{},company:{id:u.company_id,name:u.company_name},avatar:u.avatar_url}}});
 }catch(e){next(e);}
};
exports.refreshToken=async(req,res,next)=>{
 try{
  const token=req.cookies.refreshToken;if(!token)throw new AppError('Refresh token required.',401);
  let decoded;try{decoded=verifyRefreshToken(token);}catch{throw new AppError('Invalid refresh token.',401);}
  const tokens=await sequelize.transaction(async t=>{
   const [u]=await select('SELECT id,token_version,refresh_token,status FROM users WHERE id=? FOR UPDATE',[decoded.id],t);
   if(!u||u.status!=='active'||u.refresh_token!==hash(token)||Number(decoded.v||0)!==Number(u.token_version))throw new AppError('Session expired.',401);
   const out=generateTokens(u);await run('UPDATE users SET refresh_token=? WHERE id=?',[hash(out.refreshToken),u.id],t);return out;
  });cookie(res,tokens.refreshToken);res.json({success:true,data:{token:tokens.accessToken}});
 }catch(e){next(e);}
};
exports.forgotPassword=async(req,res,next)=>{
 try{
  await sequelize.transaction(async t=>{
   const [u]=await select('SELECT id,first_name,email FROM users WHERE email=?',[req.body.email],t);if(!matchesEmail(u,req.body.email))return;
   const token=crypto.randomBytes(32).toString('hex');await run('UPDATE users SET password_reset_token=?,password_reset_expires=DATE_ADD(NOW(),INTERVAL 30 MINUTE) WHERE id=?',[hash(token),u.id],t);
   await enqueue('email',{to:u.email,subject:'Reset your password',template:'reset-password',context:{name:u.first_name,resetUrl:`${process.env.FRONTEND_URL}/reset-password?token=${token}`}},t);
  });res.json({success:true,message:'If your email is registered, a reset link has been queued.'});
 }catch(e){next(e);}
};
exports.resetPassword=async(req,res,next)=>{
 try{
  const password=await bcrypt.hash(req.body.password,12);
  await sequelize.transaction(async t=>{
   const [u]=await select('SELECT id FROM users WHERE password_reset_token=? AND password_reset_expires>NOW() FOR UPDATE',[hash(req.body.token)],t);if(!u)throw new AppError('Invalid reset link.',400);
   await run('UPDATE users SET password_hash=?,password_reset_token=NULL,password_reset_expires=NULL,refresh_token=NULL,token_version=token_version+1 WHERE id=?',[password,u.id],t);
  });res.json({success:true,message:'Password changed. All previous sessions are revoked.'});
 }catch(e){next(e);}
};
exports.logout=async(req,res,next)=>{
 try{await run('UPDATE users SET refresh_token=NULL,token_version=token_version+1 WHERE id=?',[req.user.id]);res.clearCookie('refreshToken',{path:'/api/v1/auth'});res.json({success:true,message:'Signed out.'});}catch(e){next(e);}
};
exports.getProfile=async(req,res)=>res.json({success:true,data:req.user});
