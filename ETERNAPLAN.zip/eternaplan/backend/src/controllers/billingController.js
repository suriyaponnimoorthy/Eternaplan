const billing=require('../services/billing');
exports.webhook=async(req,res,next)=>{try{res.json(await billing.webhook(req.body,req.get('Stripe-Signature')));}catch(e){next(e);}};
