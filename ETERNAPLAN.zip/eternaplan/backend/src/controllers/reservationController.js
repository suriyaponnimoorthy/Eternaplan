const {sequelize}=require('../config/database'),{code}=require('../utils/ids');
const {interval,lockResources,available,select}=require('../services/reservations');const AppError=require('../utils/AppError');
const run=(sql,replacements,t)=>sequelize.query(sql,{replacements,transaction:t});
const tx=fn=>sequelize.transaction({isolationLevel:'READ COMMITTED'},fn);
exports.createEvent=async(req,res,next)=>{
 try{const id=await tx(async t=>{
  const b=req.body,range=interval(b,true);await lockResources(b.venue_id,null,req.user.company_id,t);await available('venue',b.venue_id,range,null,null,t);
  const [customer]=await select('SELECT id FROM customers WHERE id=? AND company_id=?',[b.customer_id,req.user.company_id],t);if(!customer)throw new AppError('Customer not found.',404);
  const [id]=await sequelize.query("INSERT INTO events (company_id,customer_id,category_id,venue_id,assigned_to,event_name,event_code,event_date,event_time,end_date,end_time,guest_count_estimate,budget_total,theme,notes,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'inquiry')",{replacements:[req.user.company_id,b.customer_id,b.category_id||null,b.venue_id||null,b.assigned_to||req.user.id,b.event_name,code('EVT'),b.event_date,b.event_time||null,b.end_date||null,b.end_time||null,b.guest_count_estimate||0,b.budget_total||0,b.theme||null,b.notes||null],type:sequelize.QueryTypes.INSERT,transaction:t});return id;
 });res.status(201).json({success:true,message:'Event created.',data:{id}});}catch(e){next(e);}
};
exports.updateEvent=async(req,res,next)=>{
 try{await tx(async t=>{
  const [old]=await select('SELECT * FROM events WHERE id=? AND company_id=? FOR UPDATE',[req.params.id,req.user.company_id],t);if(!old)throw new AppError('Event not found.',404);
  const merged={...old,...req.body},range=interval(merged,true);
  // Lock previous and next venues in stable order, including release paths.
  for(const vid of [...new Set([old.venue_id,merged.venue_id].filter(Boolean))].sort((a,b)=>a-b))await lockResources(vid,null,req.user.company_id,t,false);
  if(merged.status!=='cancelled')await lockResources(merged.venue_id,null,req.user.company_id,t);
  if(merged.status!=='cancelled')await available('venue',merged.venue_id,range,old.id,null,t,true);
  const moved=['venue_id','event_date','event_time','end_date','end_time'].some(k=>req.body[k]!==undefined&&String(req.body[k])!==String(old[k]));
  const [active]=await select("SELECT id FROM bookings WHERE event_id=? AND status<>'cancelled' LIMIT 1",[old.id],t);
  if(active&&(moved||merged.status==='cancelled'))throw new AppError('Cancel or reschedule supplier bookings before moving/cancelling this event.',409);
  const allowed=['event_name','category_id','venue_id','assigned_to','event_date','event_time','end_date','end_time','guest_count_estimate','guest_count_actual','theme','notes','internal_notes','budget_total','status','checklist','timeline','color_scheme','dress_code','special_requirements'];
  const fields=allowed.filter(k=>req.body[k]!==undefined);if(!fields.length)throw new AppError('No editable fields.',422);
  await run(`UPDATE events SET ${fields.map(k=>`${k}=?`).join(',')} WHERE id=?`,[...fields.map(k=>typeof req.body[k]==='object'&&req.body[k]!==null?JSON.stringify(req.body[k]):req.body[k]),old.id],t);
  // Legacy reservations are redundant with the locked event interval; release stale copies.
  await run('DELETE FROM venue_bookings WHERE event_id=?',[old.id],t);
 });res.json({success:true,message:'Event updated.'});}catch(e){next(e);}
};
exports.deleteEvent=async(req,res,next)=>{
 try{await tx(async t=>{
  const [e]=await select('SELECT * FROM events WHERE id=? AND company_id=? FOR UPDATE',[req.params.id,req.user.company_id],t);if(!e)throw new AppError('Event not found.',404);
  await lockResources(e.venue_id,null,req.user.company_id,t,false);
  const [b]=await select('SELECT id FROM bookings WHERE event_id=? LIMIT 1',[e.id],t);const [i]=await select('SELECT id FROM invoices WHERE event_id=? LIMIT 1',[e.id],t);
  if(b||i||['completed','in_progress'].includes(e.status))throw new AppError('Events with bookings or financial records cannot be deleted. Cancel them instead.',409);
  await run('DELETE FROM events WHERE id=?',[e.id],t);
 });res.json({success:true,message:'Event removed.'});}catch(e){next(e);}
};
exports.createBooking=async(req,res,next)=>{
 try{const result=await tx(async t=>{
  const b=req.body,range=interval(b);const [event]=await select('SELECT id,status FROM events WHERE id=? AND company_id=? FOR UPDATE',[b.event_id,req.user.company_id],t);
  if(!event||event.status==='cancelled')throw new AppError('Active event required.',422);
  if(b.vendor_id&&b.venue_id)throw new AppError('Choose one resource per booking.',422);
  if((b.booking_type==='venue'&&!b.venue_id)||(b.booking_type!=='venue'&&!b.vendor_id))throw new AppError('Choose a venue or supplier.',422);
  await lockResources(b.venue_id,b.vendor_id,req.user.company_id,t);
  await available('venue',b.venue_id,range,b.event_id,null,t);await available('vendor',b.vendor_id,range,b.event_id,null,t);
  if(Number(b.advance_amount||0)>Number(b.agreed_price||0))throw new AppError('Advance exceeds agreed price.',422);
  const booking_code=code('BK');const [id]=await sequelize.query("INSERT INTO bookings (company_id,event_id,vendor_id,venue_id,package_id,booking_code,booking_type,booking_date,start_time,end_date,end_time,quoted_price,agreed_price,advance_amount,balance_amount,special_requirements,notes,status,created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'pending',?)",{replacements:[req.user.company_id,b.event_id,b.vendor_id||null,b.venue_id||null,b.package_id||null,booking_code,b.booking_type||'vendor',b.booking_date,b.start_time||null,b.end_date||null,b.end_time||null,b.quoted_price||0,b.agreed_price||0,b.advance_amount||0,Number(b.agreed_price||0)-Number(b.advance_amount||0),b.special_requirements||null,b.notes||null,req.user.id],transaction:t,type:sequelize.QueryTypes.INSERT});return {id,booking_code};
 });res.status(201).json({success:true,data:result});}catch(e){next(e);}
};
exports.updateBooking=async(req,res,next)=>{
 try{await tx(async t=>{
  const [found]=await select('SELECT event_id FROM bookings WHERE id=? AND company_id=?',[req.params.id,req.user.company_id],t);if(!found)throw new AppError('Booking not found.',404);
  const [parent]=await select('SELECT id,status FROM events WHERE id=? AND company_id=? FOR UPDATE',[found.event_id,req.user.company_id],t);
  if(!parent)throw new AppError('Event not found.',404);
  if(req.body.status!=='cancelled'&&parent.status==='cancelled')throw new AppError('Bookings cannot be activated for a cancelled event.',409);
  const [b]=await select('SELECT * FROM bookings WHERE id=? FOR UPDATE',[req.params.id],t);
  await lockResources(b.venue_id,b.vendor_id,req.user.company_id,t,req.body.status!=='cancelled');
  const status=req.body.status;
  if(b.status==='completed'&&status!=='completed')throw new AppError('Completed bookings cannot change status.',409);
  if(status!=='cancelled'){const r=interval(b);await available('venue',b.venue_id,r,b.event_id,b.id,t);await available('vendor',b.vendor_id,r,b.event_id,b.id,t);}
  await run('UPDATE bookings SET status=?,cancellation_reason=?,cancelled_at=IF(?="cancelled",NOW(),NULL) WHERE id=?',[status,req.body.cancellation_reason||null,status,b.id],t);
  await run('UPDATE venue_bookings SET status=? WHERE booking_id=?',[status==='cancelled'?'cancelled':'confirmed',b.id],t);
 });res.json({success:true,message:'Booking status updated.'});}catch(e){next(e);}
};
