/**
 * EternaPlaan - Express Application Configuration
 * Middleware stack, security headers, routing
 */

const express     = require('express');
const helmet      = require('helmet');
const cors        = require('cors');
const compression = require('compression');
const morgan      = require('morgan');
const cookieParser = require('cookie-parser');
const rateLimit   = require('express-rate-limit');

const path        = require('path');

const routes      = require('./routes');
const { errorHandler, notFoundHandler } = require('./middleware/error.middleware');
const logger      = require('./utils/logger');

const app = express();
app.set('case sensitive routing',true);
app.set('strict routing',true);
app.use('/api',require('./middleware/resource.middleware').canonicalPath);
if(process.env.TRUST_PROXY_HOPS) app.set('trust proxy',Number(process.env.TRUST_PROXY_HOPS));

// ─── Security Middleware ─────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", 'data:', 'https://res.cloudinary.com'],
    },
  },
}));

// CORS
app.use(cors({
  origin: (origin, callback) => {
    const allowed = [
      process.env.FRONTEND_URL,
      'http://localhost:3000',
      'http://localhost:5173',
    ];
    if (!origin || allowed.includes(origin)) return callback(null, true);
    callback(new Error(`CORS blocked: ${origin}`));
  },
  credentials: true,
  methods: ['GET','POST','PUT','PATCH','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization','X-Refresh-Token'],
}));

// ─── Rate Limiting ───────────────────────────────────────
const globalLimiter = rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS) || 15 * 60 * 1000,
  max:      parseInt(process.env.RATE_LIMIT_MAX) || 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many requests. Please try again later.' },
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: process.env.NODE_ENV==='test' ? 100 : 10,
  message: { success: false, message: 'Too many auth attempts. Please try again in 15 minutes.' },
});

app.use('/api/', globalLimiter);
app.use('/api/v1/auth/login', authLimiter);
app.use('/api/v1/auth/register', authLimiter);
app.use('/api/v1/auth/verify-otp', authLimiter);
app.use('/api/v1/auth/forgot-password', authLimiter);
app.use('/api/v1/auth/reset-password', authLimiter);
app.use('/api/v1/auth/resend-otp', authLimiter);
app.use('/api/v1/team/accept',authLimiter);
app.use('/api/v1/mfa',authLimiter);

app.post('/api/v1/billing/webhook', express.raw({type:'application/json',limit:'1mb'}), require('./controllers/billingController').webhook);

// ─── Body Parsing ────────────────────────────────────────
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());
// Validate individual fields and render text safely; do not rewrite raw request data.
app.use(compression());

// ─── Logging ─────────────────────────────────────────────
app.use(morgan(':remote-addr :method :status :response-time ms', {
  stream: { write: (msg) => logger.http(msg.trim()) },
  skip: (req) => process.env.NODE_ENV === 'test',
}));

// ─── Static Files ────────────────────────────────────────
// Private documents are never served through a static directory.

// ─── Health Check ────────────────────────────────────────
app.get('/health', (req, res) => res.json({
  status: 'healthy',
  service: 'EternaPlaan API',
  version: '1.0.0',
  timestamp: new Date().toISOString(),
  uptime: process.uptime(),
}));

app.get('/ready',async(req,res)=>{try{await require('./config/database').sequelize.authenticate();const [rows]=await require('./config/database').sequelize.query("SELECT name FROM schema_migrations WHERE name IN ('002_hardening.sql','003_security_workflow_fixes.sql','004_revoke_pending_resets.sql')");if(rows.length!==3)throw new Error('Migration missing');res.json({ready:true});}catch{res.status(503).json({ready:false});}});

// ─── API Routes ──────────────────────────────────────────
app.use('/api/v1', routes);

// ─── Error Handling ──────────────────────────────────────
app.use(notFoundHandler);
app.use(errorHandler);

module.exports = app;
