const {sequelize}=require('../config/database');const {randomUUID}=require('crypto');const AppError=require('../utils/AppError');const {minor,major}=require('../utils/money');const {code}=require('../utils/ids');
const select=(sql,replacements,t)=>sequelize.query(sql,{replacements,transaction:t,type:sequelize.QueryTypes.SELECT});
const run=(sql,replacements,t)=>sequelize.query(sql,{replacements,transaction:t});
const tx=fn=>sequelize.transaction({isolationLevel:'READ COMMITTED'},fn);
const stripe=()=>{if(!process.env.STRIPE_SECRET_KEY)throw new AppError('Online payments are not configured.',503);return new (require('stripe'))(process.env.STRIPE_SECRET_KEY,{maxNetworkRetries:0,timeout:8000});};
async function invoiceTotals(invoiceId,t){
 const [i]=await select('SELECT * FROM invoices WHERE id=? FOR UPDATE',[invoiceId],t);
 const [sum]=await select('SELECT COALESCE(SUM(amount_minor),0) AS total FROM billing_ledger WHERE invoice_id=?',[invoiceId],t);
 const paid=Number(i.opening_paid_minor)+Number(sum.total),total=minor(i.grand_total);if(paid<0)throw new Error('Negative invoice ledger');
 await run("UPDATE invoices SET amount_paid=?,balance_due=?,status=IF(status='cancelled','cancelled',IF(?<=0,'paid',IF(?>0,'partial','sent'))),paid_at=IF(?<=0,NOW(),NULL) WHERE id=?",[major(paid),major(Math.max(0,total-paid)),total-paid,paid,total-paid,invoiceId],t);
 await run('UPDATE events SET advance_paid=(SELECT COALESCE(SUM(amount_paid),0) FROM invoices WHERE event_id=?),balance_due=(SELECT COALESCE(SUM(balance_due),0) FROM invoices WHERE event_id=?) WHERE id=?',[i.event_id,i.event_id,i.event_id],t);
}
async function ledger(order,reference,amount,kind,t,receipt=null){
 const [existing]=await select('SELECT id FROM billing_ledger WHERE provider_ref=?',[reference],t);if(existing)return;
 await run('INSERT INTO billing_ledger (company_id,invoice_id,order_id,provider_ref,amount_minor,kind,receipt_metadata) VALUES (?,?,?,?,?,?,?)',[order.company_id,order.invoice_id,order.id||null,reference,amount,kind,receipt?JSON.stringify(receipt):null],t);
 const [i]=await select('SELECT customer_id FROM invoices WHERE id=?',[order.invoice_id],t);
 await run("INSERT INTO payments (company_id,invoice_id,customer_id,payment_code,amount,payment_date,payment_method,payment_ref,gateway_name,gateway_txn_id,status,payment_type) VALUES (?,?,?,?,?,COALESCE(?,CURDATE()),?,?,?,?, 'completed',?)",[
  order.company_id,order.invoice_id,i.customer_id,code('PAY'),major(amount),receipt?.date??null,
  receipt?.method??'online',receipt?receipt.reference:reference,receipt?'manual':'stripe',receipt?null:reference,
  receipt?.type??(kind==='refund'?'refund':'full')
 ],t);
 await invoiceTotals(order.invoice_id,t);
}
const activeStates = "('created','open','recovery_required')";
const retryWindow = 23 * 3600000;
const absenceWindow = 24 * 3600000;
const parseJson = value => typeof value === 'string' ? JSON.parse(value) : value;
const result = (id,state,url=null) => ({id,state,url});
async function providerAccount(client){
 const account=await client.accounts.retrieve();
 if(!account?.id)throw new AppError('Could not identify the payment provider account.',503);
 const key=process.env.STRIPE_SECRET_KEY||'';
 return account.id + (/^(?:sk|rk)_live_/.test(key)?':live':':test');
}
function checkoutPayload(order){
 return {
  mode:'payment',client_reference_id:order.id,metadata:{local_order:order.id},
  payment_intent_data:{metadata:{local_order:order.id}},
  line_items:[{price_data:{currency:order.currency,unit_amount:order.amount_minor,
   product_data:{name:`EternaPlaan invoice ${order.invoice_id}`}},quantity:1}],
  success_url:`${process.env.FRONTEND_URL}/finance/payments?checkout=returned`,
  cancel_url:`${process.env.FRONTEND_URL}/finance/payments?checkout=cancelled`
 };
}
async function checkout(company,invoiceId,requestKey,client=stripe()){
 const account=await providerAccount(client);
 const orderId=await tx(async t=>{
  const [i]=await select('SELECT * FROM invoices WHERE id=? AND company_id=? FOR UPDATE',[invoiceId,company],t);
  if(!i||i.status==='cancelled')throw new AppError('Invoice not found.',404);
  const [old]=await select('SELECT id,invoice_id FROM billing_orders WHERE company_id=? AND request_key=?',[company,requestKey],t);
  if(old){
   if(Number(old.invoice_id)!==Number(invoiceId))throw new AppError('Idempotency key used for a different invoice.',409);
   return old.id;
  }
  const [active]=await select(`SELECT id FROM billing_orders WHERE invoice_id=? AND state IN ${activeStates} LIMIT 1`,[invoiceId],t);
  if(active)throw new AppError('A checkout is already pending. Recover it from the order list.',409);
  const amount=minor(i.balance_due);
  if(amount<=0)throw new AppError('Invoice has no outstanding balance.',409);
  const order={id:randomUUID(),invoice_id:i.id,amount_minor:amount,currency:'inr'};
  await run('INSERT INTO billing_orders (id,company_id,invoice_id,amount_minor,request_key,provider_account_id,checkout_payload) VALUES (?,?,?,?,?,?,?)',
   [order.id,company,invoiceId,amount,requestKey,account,JSON.stringify(checkoutPayload(order))],t);
  return order.id;
 });
 return recoverCheckout(company,orderId,'retry',client,account);
}
async function findSession(client,order){
 const lower=Math.floor(new Date(order.created_at).getTime()/1000)-300;
 const upper=Math.ceil((new Date(order.created_at).getTime()+absenceWindow)/1000)+300;
 const query={created:{gte:lower,...(order.checkout_payload?{lte:upper}:{})},limit:100};
 let found;
 for(let page=0;page<5;page++){
  const sessions=await client.checkout.sessions.list(query);
  for(const session of sessions.data){
   if(session.metadata?.local_order!==order.id&&session.client_reference_id!==order.id)continue;
   if(found)throw new Error('More than one matching session');
   assertSession(order,session);
   found=session;
  }
  if(!sessions.has_more)return {session:found,complete:true};
  if(!sessions.data.length)break;
  query.starting_after=sessions.data.at(-1).id;
 }
 return {complete:false};
}
async function recoverCheckout(company,id,action,client=stripe(),knownAccount){
 return tx(async t=>{
  const [order]=await select('SELECT * FROM billing_orders WHERE company_id=? AND id=? FOR UPDATE',[company,id],t);
  if(!order)throw new AppError('Order not found.',404);
  if(['failed','expired'].includes(order.state))return result(id,order.state);
  const account=knownAccount||await providerAccount(client);
  if(order.provider_account_id&&order.provider_account_id!==account)throw new AppError('Reconnect the original Stripe account and mode to recover this order.',409);
  const age=Date.now()-new Date(order.created_at).getTime();
  const uncertain=async reason=>{
   await run("UPDATE billing_orders SET state=IF(state='paid','paid','recovery_required'),last_error_code=? WHERE id=?",[reason,id],t);
   return result(id,order.state==='paid'?'paid':'recovery_required');
  };
  let session;
  try{
   if(order.session_id)session=await client.checkout.sessions.retrieve(order.session_id);
   else if(action==='retry'&&order.checkout_payload&&age>=0&&age<retryWindow){
    const created=await client.checkout.sessions.create(parseJson(order.checkout_payload),{idempotencyKey:`order-${id}`});
    // An idempotent response can contain an earlier snapshot of the session.
    session=await client.checkout.sessions.retrieve(created.id);
   }else{
    const lookup=await findSession(client,order);
    if(!lookup.complete)return uncertain('search_incomplete');
    session=lookup.session;
   }
   if(session){
    assertSession(order,session);
    if(action==='cancel'&&session.status==='open'&&session.payment_status!=='paid'){
     try{session=await client.checkout.sessions.expire(session.id);}
     catch{session=await client.checkout.sessions.retrieve(session.id);}
     assertSession(order,session);
    }
   }
  }catch{return uncertain('provider_unconfirmed');}
  if(!session){
   // A recently timed-out request may still be executing on the provider.
   if(!order.provider_account_id||!order.checkout_payload||age<absenceWindow+300000)return uncertain('absence_unconfirmed');
   await run("UPDATE billing_orders SET state='failed',last_error_code=NULL WHERE id=?",[id],t);
   return result(id,'failed');
  }
  const state=await settleSession(session,t);
  await run('UPDATE billing_orders SET provider_account_id=COALESCE(provider_account_id,?) WHERE id=?',[account,id],t);
  if(action==='cancel'&&state==='open')return uncertain('expiration_unconfirmed');
  return result(id,state,state==='open'?session.url:null);
 });
}
function assertSession(order,session){
 if(!session?.id||session.metadata?.local_order!==order.id||session.client_reference_id!==order.id||
    Number(session.amount_total)!==Number(order.amount_minor)||session.currency!==order.currency||
    (order.session_id&&session.id!==order.session_id))throw new AppError('Provider order does not match local invoice.',409);
}
async function settleSession(session,t){
 const local=session.metadata?.local_order;if(!local)return;
 const [o]=await select('SELECT * FROM billing_orders WHERE id=? FOR UPDATE',[local],t);if(!o)return;
 await select('SELECT id FROM invoices WHERE id=? FOR UPDATE',[o.invoice_id],t);
 assertSession(o,session);
 if(session.payment_status==='paid'){
  const intent=typeof session.payment_intent==='object'?session.payment_intent.id:session.payment_intent;if(!intent)throw new AppError('Payment identifier missing.',409);
  await run("UPDATE billing_orders SET state='paid',session_id=?,payment_intent=?,last_error_code=NULL WHERE id=?",[session.id,intent,o.id],t);
  await ledger(o,intent,Number(o.amount_minor),'capture',t);
  return 'paid';
 }
 if(o.state==='paid')return 'paid';
 if(o.state==='expired')return 'expired';
 if(session.status==='expired'){
  await run("UPDATE billing_orders SET state='expired',session_id=?,session_url=NULL,last_error_code=NULL WHERE id=?",[session.id,o.id],t);
  return 'expired';
 }
 const state=session.status==='open'?'open':'recovery_required';
 await run('UPDATE billing_orders SET state=?,session_id=?,session_url=?,last_error_code=? WHERE id=?',
  [state,session.id,state==='open'?session.url:null,state==='open'?null:'payment_pending',o.id],t);
 return state;
}

async function settleRefund(refund,t){
 const [o]=await select('SELECT * FROM billing_orders WHERE payment_intent=? FOR UPDATE',[typeof refund.payment_intent==='object'?refund.payment_intent.id:refund.payment_intent],t);if(!o)return;
 await select('SELECT id FROM invoices WHERE id=? FOR UPDATE',[o.invoice_id],t);
 if(refund.currency!==o.currency||!Number.isSafeInteger(refund.amount)||refund.amount<=0)throw new AppError('Refund mismatch.',409);
 const [prior]=await select('SELECT * FROM billing_refunds WHERE provider_refund_id=?',[refund.id],t);
 const local=refund.metadata?.local_refund;
 const [requested]=local?await select('SELECT * FROM billing_refunds WHERE id=? AND order_id=?',[local,o.id],t):[];
 if(requested&&Number(requested.amount_minor)!==refund.amount)throw new AppError('Refund amount mismatch.',409);
 const r=prior||requested;
 if(!r)await run('INSERT INTO billing_refunds (id,company_id,order_id,request_key,amount_minor,provider_refund_id,state) VALUES (?,?,?,?,?,?,?)',[randomUUID(),o.company_id,o.id,`external-${refund.id}`,refund.amount,refund.id,refund.status],t);
 else await run("UPDATE billing_refunds SET provider_refund_id=?,state=IF(state='succeeded','succeeded',?) WHERE id=?",[refund.id,refund.status,r.id],t);
 if(refund.status==='succeeded'){
  const [total]=await select("SELECT COALESCE(-SUM(amount_minor),0) AS amount FROM billing_ledger WHERE order_id=? AND kind='refund'",[o.id],t);
  const [exists]=await select('SELECT id FROM billing_ledger WHERE provider_ref=?',[refund.id],t);
  if(!exists&&Number(total.amount)+refund.amount>Number(o.amount_minor))throw new AppError('Refund exceeds captured amount.',409);
  await ledger(o,refund.id,-refund.amount,'refund',t);
 }
}
async function refund(company,orderId,amount,requestKey,client=stripe()){
 const r=await tx(async t=>{
  const [o]=await select('SELECT * FROM billing_orders WHERE id=? AND company_id=? FOR UPDATE',[orderId,company],t);if(!o||o.state!=='paid')throw new AppError('Captured order required.',409);
  const [old]=await select('SELECT * FROM billing_refunds WHERE company_id=? AND request_key=?',[company,requestKey],t);if(old){if(old.order_id!==orderId||Number(old.amount_minor)!==amount)throw new AppError('Idempotency key parameters changed.',409);return {...old,payment_intent:o.payment_intent};}
  const [sum]=await select("SELECT COALESCE(SUM(amount_minor),0) AS total FROM billing_refunds WHERE order_id=? AND state NOT IN ('failed','canceled')",[o.id],t);if(Number(sum.total)+amount>Number(o.amount_minor))throw new AppError('Refund exceeds remaining refundable amount.',409);
  const result={id:randomUUID(),order_id:o.id,amount_minor:amount,payment_intent:o.payment_intent,created_at:new Date()};await run('INSERT INTO billing_refunds (id,company_id,order_id,request_key,amount_minor) VALUES (?,?,?,?,?)',[result.id,company,o.id,requestKey,amount],t);return result;
 });
 if(r.provider_refund_id)return {id:r.id,state:r.state};
 if(Date.now()-new Date(r.created_at)>23*3600000)throw new AppError('Refund outcome uncertain. Reconcile before retrying.',409);
 const result=await client.refunds.create({payment_intent:r.payment_intent,amount,metadata:{local_refund:r.id}},{idempotencyKey:`refund-${r.id}`});
 await tx(t=>settleRefund(result,t));return {id:r.id,state:result.status};
}
async function webhook(raw,signature,client=stripe()){
 if(!process.env.STRIPE_WEBHOOK_SECRET)throw new AppError('Webhook not configured.',503);
 let event;try{event=client.webhooks.constructEvent(raw,signature,process.env.STRIPE_WEBHOOK_SECRET);}catch{throw new AppError('Invalid webhook signature.',400);}
 const object=event.data.object;
 let current=null,kind=null;
 if(['checkout.session.completed','checkout.session.async_payment_succeeded','checkout.session.expired'].includes(event.type)){current=await client.checkout.sessions.retrieve(object.id);kind='session';}
 if(['refund.created','refund.updated','refund.failed'].includes(event.type)){current=await client.refunds.retrieve(object.id);kind='refund';}
 await tx(async t=>{
  // A unique event ID and ledger provider reference prevent double application, including concurrent deliveries.
  const [seen]=await select('SELECT id FROM billing_webhook_events WHERE id=?',[event.id],t);if(seen)return;
  if(kind==='session')await settleSession(current,t);if(kind==='refund')await settleRefund(current,t);
  await run('INSERT INTO billing_webhook_events (id,event_type) VALUES (?,?)',[event.id,event.type],t);
 }).catch(async error=>{
  if(error.name==='SequelizeUniqueConstraintError'){const [done]=await select('SELECT id FROM billing_webhook_events WHERE id=?',[event.id]);if(done)return;}
  throw error;
 });return {received:true};
}
async function reconcile(company,id,client=stripe()){
 const recovered=await recoverCheckout(company,id,'reconcile',client);
 if(recovered.state==='paid'){
  const [order]=await select('SELECT payment_intent,last_error_code FROM billing_orders WHERE id=? AND company_id=?',[id,company]);
  if(order.last_error_code)throw new AppError('Could not verify the current provider state.',503);
  const rs=await client.refunds.list({payment_intent:order.payment_intent,limit:100});
  for(const refund of rs.data)await tx(t=>settleRefund(refund,t));
  if(rs.has_more)throw new AppError('More than 100 refunds; manual reconciliation required.',409);
 }
 return recovered;
}
async function manual(company,userId,b){
 return tx(async t=>{
  const [i]=await select('SELECT * FROM invoices WHERE id=? AND company_id=? FOR UPDATE',[b.invoice_id,company],t);if(!i||i.status==='cancelled')throw new AppError('Invoice not found.',404);
  const ref=`manual:${company}:${b.request_key}`,[exists]=await select('SELECT id,amount_minor,invoice_id,receipt_metadata FROM billing_ledger WHERE provider_ref=?',[ref],t);
  const amount=minor(b.amount);
  const prior=parseJson(exists?.receipt_metadata);
  const [today]=await select("SELECT DATE_FORMAT(CURDATE(),'%Y-%m-%d') AS date",[],t);
  const receipt={method:b.payment_method??'other',date:b.payment_date??prior?.date??today.date,
   reference:b.payment_ref?.trim()||null,type:b.payment_type??'full'};
  if(exists){
   const changed=prior&&Object.keys(receipt).some(key=>receipt[key]!==prior[key]);
   if(Number(exists.invoice_id)!==Number(i.id)||Number(exists.amount_minor)!==amount||changed)throw new AppError('Idempotency key parameters changed.',409);
   return;
  }
  const [active]=await select(`SELECT id FROM billing_orders WHERE invoice_id=? AND state IN ${activeStates} LIMIT 1`,[i.id],t);
  if(active)throw new AppError('Reconcile or expire the online checkout before recording manual payment.',409);
  if(amount<=0||amount>minor(i.balance_due))throw new AppError('Payment must be positive and within invoice balance.',422);
  await ledger({company_id:company,invoice_id:i.id},ref,amount,'manual',t,receipt);
  await run("INSERT INTO audit_logs (user_id,company_id,action,entity_type,entity_id,new_data) VALUES (?,?,'manual_payment','invoice',?,?)",
   [userId,company,i.id,JSON.stringify({...receipt,amount_minor:amount})],t);
 });
}
module.exports={checkout,refund,webhook,reconcile,recoverCheckout,manual,invoiceTotals,settleSession,settleRefund};
