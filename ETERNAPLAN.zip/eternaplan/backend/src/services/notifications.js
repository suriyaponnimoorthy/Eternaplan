const {sequelize}=require('../config/database');
const {seal,open}=require('../utils/crypto');
const {randomUUID}=require('crypto');
exports.enqueue=async(kind,payload,transaction)=>{
 await sequelize.query('INSERT INTO notification_jobs (id,kind,payload,available_at) VALUES (?,?,?,NOW())',{replacements:[randomUUID(),kind,JSON.stringify(seal(Buffer.from(JSON.stringify(payload))))],transaction});
};
exports.deliverOne=async()=>{
 const lease=randomUUID();
 const job=await sequelize.transaction(async t=>{
  const [row]=await sequelize.query("SELECT * FROM notification_jobs WHERE (state='pending' OR (state='sending' AND locked_until<NOW())) AND available_at<=NOW() AND attempts<5 ORDER BY available_at LIMIT 1 FOR UPDATE SKIP LOCKED",{type:sequelize.QueryTypes.SELECT,transaction:t});
  if(!row)return null;
  await sequelize.query("UPDATE notification_jobs SET state='sending',attempts=attempts+1,locked_until=DATE_ADD(NOW(), INTERVAL 90 SECOND),lease_token=? WHERE id=?",{replacements:[lease,row.id],transaction:t});return row;
 });
 if(!job)return false;
 try{
  const payload=JSON.parse(open(typeof job.payload==='string'?JSON.parse(job.payload):job.payload).toString());
  if(job.kind==='email')await require('../utils/email').sendEmail(payload);
  else if(job.kind==='sms')await require('../utils/sms').sendSMS(payload);
  else throw new Error('unsupported notification');
  await sequelize.query("UPDATE notification_jobs SET state='sent',payload=JSON_OBJECT(),last_error=NULL WHERE id=? AND lease_token=?",{replacements:[job.id,lease]});
 }catch{
  require('../utils/logger').warn('Notification delivery failed',{job_id:job.id,attempt:job.attempts+1});
  await sequelize.query("UPDATE notification_jobs SET state=IF(attempts>=5,'failed','pending'),last_error='Delivery failed; inspect provider configuration',available_at=DATE_ADD(NOW(),INTERVAL 2 MINUTE) WHERE id=? AND lease_token=?",{replacements:[job.id,lease]});
 }
 return true;
};
