// Explainable content-based matching. No fabricated review or availability data.
const positive = value => value != null && Number.isFinite(Number(value)) && Number(value) > 0;
function rankCandidates(rows, preferences, kind) {
  const city = preferences.city?.trim().toLowerCase();
  const budget = Number(preferences.budget || 0); // per supplier, not total event budget
  const guests = Number(preferences.guests || 0);
  return rows.filter(row => {
    if (city && row.city?.trim().toLowerCase() !== city) return false;
    if (kind === 'venue' && guests && Number(row.capacity_max) < guests) return false;
    if (kind === 'vendor' && preferences.category_id && Number(row.category_id) !== Number(preferences.category_id)) return false;
    const price = kind === 'venue' ? (row.price_per_day ?? row.base_price) : row.min_price;
    return !(budget && positive(price) && Number(price) > budget);
  }).map(row => {
    const reasons = [], warnings = [];
    let score = 0;
    if (city) { score += 30; reasons.push(`Located in ${row.city}`); }
    const price = kind === 'venue' ? (row.price_per_day ?? row.base_price) : row.min_price;
    if (positive(price)) {
      if (budget) { score += 25; reasons.push('Listed starting price fits your per-supplier budget'); }
    } else warnings.push('Price unavailable — request a quote');
    if (kind === 'venue' && guests) {
      score += 25 * guests / Number(row.capacity_max);
      reasons.push(`Capacity ${row.capacity_max} accommodates ${guests} guests`);
    }
    if (kind === 'vendor' && preferences.category_id) { score += 25; reasons.push(`Matches ${row.category}`); }
    const reviews = Math.max(0, Number(row.total_reviews || 0));
    if (reviews) {
      score += 20 * Math.min(5, Math.max(0, Number(row.rating || 0))) / 5 * reviews / (reviews + 5);
      reasons.push(`${row.rating}/5 from ${reviews} reviews`);
    } else warnings.push('No review history available');
    warnings.push(preferences.date ? 'No recorded date conflict; confirm availability directly' : 'Date not selected; availability not checked');
    warnings.push('Starting prices are indicative; taxes, extras and final quote may differ');
    return { ...row, kind, score: Math.round(score), reasons, warnings, starting_price: positive(price) ? Number(price) : null };
  }).sort((a,b) => b.score - a.score || a.id - b.id).slice(0, 6);
}
module.exports = { rankCandidates };
