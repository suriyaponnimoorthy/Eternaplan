const {sequelize}=require('../config/database');const AppError=require('../utils/AppError');
const select=(sql,replacements,t)=>sequelize.query(sql,{replacements,transaction:t,type:sequelize.QueryTypes.SELECT});
function interval(data,isEvent=false){
 const date=isEvent?data.event_date:data.booking_date;
 const start=isEvent?data.event_time:data.start_time,end=data.end_time;
 const validDate=v=>/^\d{4}-\d{2}-\d{2}$/.test(v||'') && new Date(v+'T00:00:00Z').toISOString().slice(0,10)===v;
 if(!validDate(date)||data.end_date&&!validDate(data.end_date))throw new AppError('Valid dates are required.',422);
 const time=v=>/^([01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?$/.test(v||'');
 if(start&&!time(start)||end&&!time(end))throw new AppError('Invalid time.',422);
 const from=`${date} ${start?(start.length===5?start+':00':start):'00:00:00'}`,to=`${data.end_date||date} ${end?(end.length===5?end+':00':end):'23:59:59'}`;
 if(to<=from)throw new AppError('End must be after start. For overnight events select an end date.',422);
 return {from,to,date,endDate:data.end_date||date,startTime:from.slice(11),endTime:to.slice(11)};
}
async function lockResources(venue,vendor,company,t,requireActive=true){
 for(const [table,id] of [['venues',venue],['vendors',vendor]])if(id){
  const [r]=await select(`SELECT id FROM ${table} WHERE id=? AND (company_id=? OR company_id IS NULL) ${requireActive?(table==='venues'?'AND is_available=1':"AND approval_status='approved'"):''} FOR UPDATE`,[id,company],t);
  if(!r)throw new AppError('Resource unavailable.',404);
 }
}
async function available(kind,resource,range,eventId,bookingId,t,ignoreOwnEvent=false){
 if(!resource)return;
 const [booked]=await select(`SELECT id FROM bookings WHERE ${kind}_id=? AND id<> ? AND (? = 0 OR event_id<> ?) AND status<>'cancelled' AND approval_status<>'rejected'
 AND TIMESTAMP(booking_date,COALESCE(start_time,'00:00:00'))< ? AND TIMESTAMP(COALESCE(end_date,booking_date),COALESCE(end_time,'23:59:59'))> ? LIMIT 1`,[resource,bookingId||0,ignoreOwnEvent?1:0,eventId||0,range.to,range.from],t);
 if(booked)throw new AppError(`${kind} is already reserved for this interval.`,409);
 if(kind==='venue'){
  const [event]=await select("SELECT id FROM events WHERE venue_id=? AND id<> ? AND status<>'cancelled' AND TIMESTAMP(event_date,COALESCE(event_time,'00:00:00'))< ? AND TIMESTAMP(COALESCE(end_date,event_date),COALESCE(end_time,'23:59:59'))> ? LIMIT 1",[resource,eventId||0,range.to,range.from],t);
  const [legacy]=await select("SELECT id FROM venue_bookings WHERE venue_id=? AND event_id<> ? AND status IN ('reserved','confirmed') AND TIMESTAMP(booked_date,COALESCE(start_time,'00:00:00'))< ? AND TIMESTAMP(booked_date,COALESCE(end_time,'23:59:59'))> ? LIMIT 1",[resource,eventId||0,range.to,range.from],t);
  if(event||legacy)throw new AppError('Venue is already reserved for this interval.',409);
 }
}
module.exports={interval,lockResources,available,select};
