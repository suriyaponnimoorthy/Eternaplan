require('dotenv').config();
require('./config/environment').validateEnvironment();
const {deliverOne}=require('./services/notifications');
const {sequelize}=require('./config/database');
let stopped=false;
process.on('SIGTERM',()=>{stopped=true;});process.on('SIGINT',()=>{stopped=true;});
(async()=>{await sequelize.authenticate();while(!stopped){try{await sequelize.query('DELETE FROM request_quotas WHERE expires_at<NOW() LIMIT 100');if(!await deliverOne())await new Promise(r=>setTimeout(r,2000));}catch{await new Promise(r=>setTimeout(r,5000));}}await sequelize.close();})().catch(()=>process.exit(1));
