const crypto=require('crypto');
exports.hash=value=>crypto.createHash('sha256').update(String(value)).digest('hex');
exports.seal=(value)=>{
 const key=Buffer.from(process.env.DATA_ENCRYPTION_KEY||'','hex');if(key.length!==32)throw new Error('DATA_ENCRYPTION_KEY must be 64 hex characters');
 const nonce=crypto.randomBytes(12), cipher=crypto.createCipheriv('aes-256-gcm',key,nonce);
 const encrypted=Buffer.concat([cipher.update(value),cipher.final()]);
 return {nonce:nonce.toString('hex'),tag:cipher.getAuthTag().toString('hex'),data:encrypted.toString('base64')};
};
exports.open=(sealed)=>{
 const key=Buffer.from(process.env.DATA_ENCRYPTION_KEY||'','hex'), decipher=crypto.createDecipheriv('aes-256-gcm',key,Buffer.from(sealed.nonce,'hex'));
 decipher.setAuthTag(Buffer.from(sealed.tag,'hex'));return Buffer.concat([decipher.update(Buffer.from(sealed.data,'base64')),decipher.final()]);
};
