const { randomUUID }=require('crypto');
exports.code=prefix=>`${prefix}-${randomUUID().replace(/-/g,'').slice(0,24)}`;
