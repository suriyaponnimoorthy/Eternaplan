const crypto=require('crypto');
const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function encode(bytes){let bits=0,value=0,out='';for(const b of bytes){value=(value<<8)|b;bits+=8;while(bits>=5){out+=alphabet[(value>>>(bits-5))&31];bits-=5;}}if(bits)out+=alphabet[(value<<(5-bits))&31];return out;}
function decode(s){let bits=0,value=0,out=[];for(const c of s){const n=alphabet.indexOf(c);if(n<0)throw Error('Invalid secret');value=(value<<5)|n;bits+=5;if(bits>=8){out.push((value>>>(bits-8))&255);bits-=8;}}return Buffer.from(out);}
function token(secret,step){const count=Buffer.alloc(8);count.writeBigUInt64BE(BigInt(step));const digest=crypto.createHmac('sha1',decode(secret)).update(count).digest(),offset=digest[19]&15;return ((digest.readUInt32BE(offset)&0x7fffffff)%1000000).toString().padStart(6,'0');}
function verify(secret,code,lastStep=0,now=Date.now()){if(!/^\d{6}$/.test(code||''))return null;const step=Math.floor(now/30000);for(const n of [step-1,step,step+1])if(n>lastStep&&crypto.timingSafeEqual(Buffer.from(token(secret,n)),Buffer.from(code)))return n;return null;}
module.exports={generate:()=>encode(crypto.randomBytes(20)),encode,token,verify};
