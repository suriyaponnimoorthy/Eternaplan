const AppError=require('./AppError');
exports.minor=value=>{const s=String(value);if(!/^\d{1,9}(\.\d{1,2})?$/.test(s))throw new AppError('Use a positive currency amount with at most two decimals.',422);const [a,b='']=s.split('.');return Number(a)*100+Number(b.padEnd(2,'0'));};
exports.major=value=>(Number(value)/100).toFixed(2);
