const jwt=require('jsonwebtoken');
const {randomUUID}=require('crypto');
exports.generateTokens=user=>({
 accessToken:jwt.sign({id:user.id,v:Number(user.token_version||0)},process.env.JWT_SECRET,{expiresIn:process.env.JWT_EXPIRES_IN||'15m'}),
 refreshToken:jwt.sign({id:user.id,v:Number(user.token_version||0),jti:randomUUID()},process.env.JWT_REFRESH_SECRET,{expiresIn:process.env.JWT_REFRESH_EXPIRES_IN||'7d'})
});
exports.verifyRefreshToken=token=>jwt.verify(token,process.env.JWT_REFRESH_SECRET);
