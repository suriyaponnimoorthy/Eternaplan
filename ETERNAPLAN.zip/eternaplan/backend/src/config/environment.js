exports.validateEnvironment=()=>{
 for(const k of ['JWT_SECRET','JWT_REFRESH_SECRET'])if((process.env[k]||'').length<48)throw new Error(`${k} must contain at least 48 characters`);
 if(process.env.JWT_SECRET===process.env.JWT_REFRESH_SECRET)throw new Error('JWT signing secrets must be different');
 if(!/^[0-9a-f]{64}$/i.test(process.env.DATA_ENCRYPTION_KEY||''))throw new Error('DATA_ENCRYPTION_KEY must be 64 hexadecimal characters');
 if(process.env.NODE_ENV==='production'){
  if(!/^https:\/\//.test(process.env.FRONTEND_URL||''))throw new Error('Production FRONTEND_URL must use HTTPS');
  if(process.env.UPLOAD_SCAN_REQUIRED!=='true')throw new Error('Production private uploads require malware scanning');
  for(const k of ['DB_PASSWORD'])if(!process.env[k]||/password|change_this/i.test(process.env[k]))throw new Error(`Set a strong ${k}`);
 }
};
