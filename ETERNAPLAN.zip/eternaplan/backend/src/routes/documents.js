const router=require('express').Router({caseSensitive:true,strict:true}),multer=require('multer'),crypto=require('crypto'),fs=require('fs/promises'),path=require('path'),os=require('os');
const {execFile}=require('child_process');const {promisify}=require('util');
const {authorize}=require('../middleware/auth.middleware');const {sequelize}=require('../config/database');const {seal,open}=require('../utils/crypto');const AppError=require('../utils/AppError');
const root=()=>path.resolve(process.env.PRIVATE_UPLOAD_DIR||'private-uploads');
router.use(authorize('admin','super_admin'));
const upload=multer({storage:multer.memoryStorage(),limits:{fileSize:5*1024*1024,files:1,fields:0}}).single('file');
const mime=bytes=>bytes.subarray(0,5).toString()==='%PDF-'?'application/pdf':bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))?'image/png':bytes.subarray(0,3).equals(Buffer.from([255,216,255]))?'image/jpeg':null;
router.post('/',upload,async(req,res,next)=>{
 let temp;
 try{
  if(!req.file)throw new AppError('Upload a PDF, PNG or JPEG.',422);const type=mime(req.file.buffer);if(!type)throw new AppError('Unsupported file signature.',422);
  if(process.env.UPLOAD_SCAN_REQUIRED==='true'){
   temp=await fs.mkdtemp(path.join(os.tmpdir(),'ep-scan-'));const filename=path.join(temp,'upload');await fs.writeFile(filename,req.file.buffer,{mode:0o600});
   try{await promisify(execFile)('clamdscan',['--no-summary','--stream',filename],{timeout:20000});}catch{throw new AppError('Upload could not pass malware scanning.',422);}
  }
  const id=crypto.randomUUID(),sealed=seal(req.file.buffer);await fs.mkdir(root(),{recursive:true,mode:0o700});const target=path.join(root(),id);
  await fs.writeFile(target,Buffer.from(sealed.data,'base64'),{mode:0o600,flag:'wx'});
  try{await sequelize.query('INSERT INTO private_documents (id,company_id,uploaded_by,original_name,mime_type,size_bytes,nonce,auth_tag) VALUES (?,?,?,?,?,?,?,?)',{replacements:[id,req.user.company_id,req.user.id,path.basename(req.file.originalname).slice(0,200),type,req.file.size,sealed.nonce,sealed.tag]});}catch(e){await fs.unlink(target);throw e;}
  res.status(201).json({success:true,data:{id}});
 }catch(e){next(e);}finally{if(temp)await fs.rm(temp,{recursive:true,force:true});}
});
router.get('/',async(req,res,next)=>{try{const rows=await sequelize.query('SELECT id,original_name,mime_type,size_bytes,created_at FROM private_documents WHERE company_id=? ORDER BY created_at DESC LIMIT 100',{replacements:[req.user.company_id],type:sequelize.QueryTypes.SELECT});res.json({success:true,data:rows});}catch(e){next(e);}});
router.get('/:id',async(req,res,next)=>{
 try{const [d]=await sequelize.query('SELECT * FROM private_documents WHERE id=? AND company_id=?',{replacements:[req.params.id,req.user.company_id],type:sequelize.QueryTypes.SELECT});if(!d)throw new AppError('Document not found.',404);
 const bytes=await fs.readFile(path.join(root(),d.id));const data=open({nonce:d.nonce,tag:d.auth_tag,data:bytes.toString('base64')});
 await sequelize.query("INSERT INTO audit_logs (user_id,company_id,action,entity_type,new_data) VALUES (?,?,'download','private_document',?)",{replacements:[req.user.id,req.user.company_id,JSON.stringify({document_id:d.id})]});
 res.set({'Content-Type':d.mime_type,'Content-Disposition':`attachment; filename="document-${d.id}.${d.mime_type==='application/pdf'?'pdf':d.mime_type==='image/png'?'png':'jpg'}"`,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}).send(data);
 }catch(e){next(e);}
});
module.exports=router;module.exports.mime=mime;
