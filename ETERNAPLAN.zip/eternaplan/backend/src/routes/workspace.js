const router=require('express').Router({caseSensitive:true,strict:true});const {sequelize}=require('../config/database');const {body}=require('express-validator');const {validateRequest}=require('../middleware/validate.middleware');
const {authorize}=require('../middleware/auth.middleware');
const wrap=fn=>async(req,res,next)=>{try{res.json({success:true,data:await fn(req)});}catch(e){next(e);}};
router.post('/tasks',authorize('admin','super_admin','event_manager'),require('../middleware/input.middleware').required('event_id','title'),(req,res,next)=>{req.params.id=req.body.event_id;require('../controllers/eventController').createTask(req,res,next);});
router.get('/tasks',wrap(r=>sequelize.query('SELECT t.*,e.event_name FROM event_tasks t JOIN events e ON t.event_id=e.id WHERE e.company_id=? ORDER BY t.due_date LIMIT 100',{replacements:[r.user.company_id],type:sequelize.QueryTypes.SELECT})));
router.get('/finance/payments',wrap(r=>sequelize.query('SELECT p.*,i.invoice_number FROM payments p LEFT JOIN invoices i ON p.invoice_id=i.id WHERE p.company_id=? ORDER BY p.created_at DESC LIMIT 100',{replacements:[r.user.company_id],type:sequelize.QueryTypes.SELECT})));
router.get('/settings',wrap(async r=>{
 const [u]=await sequelize.query('SELECT first_name,last_name,email,preferences FROM users WHERE id=?',{replacements:[r.user.id],type:sequelize.QueryTypes.SELECT});return u;
}));
router.put('/settings',[body('first_name').isString().trim().isLength({min:1,max:100}),body('last_name').isString().trim().isLength({min:1,max:100})],validateRequest,wrap(async r=>{await sequelize.query('UPDATE users SET first_name=?,last_name=? WHERE id=?',{replacements:[r.body.first_name,r.body.last_name,r.user.id]});return {saved:true};}));
router.get('/audit',authorize('admin','super_admin'),wrap(r=>sequelize.query('SELECT id,action,entity_type,entity_id,created_at FROM audit_logs WHERE company_id=? ORDER BY created_at DESC LIMIT 100',{replacements:[r.user.company_id],type:sequelize.QueryTypes.SELECT})));
module.exports=router;
