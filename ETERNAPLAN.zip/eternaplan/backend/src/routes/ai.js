const router = require('express').Router({caseSensitive:true,strict:true});
const { body } = require('express-validator');
const rateLimit = require('express-rate-limit');
const { authenticate } = require('../middleware/auth.middleware');
const { validateRequest } = require('../middleware/validate.middleware');
const ctrl = require('../controllers/aiController');
const preferences = [
  body('preferences').optional().isObject(),
  body('preferences.city').optional().isString().trim().isLength({max:100}),
  body('preferences.guests').optional().isInt({min:0,max:1000000}).toInt(),
  body('preferences.budget').optional().isFloat({min:0,max:1000000000}).toFloat(),
  body('preferences.category_id').optional().isInt({min:1}).toInt(),
  body('preferences.date').optional().isISO8601({strict:true}).matches(/^\d{4}-\d{2}-\d{2}$/),
];
router.use(authenticate);
router.use(rateLimit({ windowMs:60000, max:20, keyGenerator:req=>String(req.user.id), standardHeaders:true, legacyHeaders:false,
  message:{success:false,message:'Assistant limit reached. Please try again in a minute.'} }));
router.post('/recommendations', preferences, validateRequest, ctrl.recommendations);
router.post('/chat', require('../middleware/quota.middleware').quota('ai-user',20,60000,r=>r.user.id), require('../middleware/quota.middleware').quota('ai-company',Number(process.env.AI_DAILY_REQUEST_LIMIT)||500,86400000,r=>r.user.company_id), preferences,
  body('message').isString().trim().isLength({min:1,max:2000}),
  body('use_ai').optional().isBoolean({strict:true}),
  body('history').optional().isArray({max:10}),
  body('history.*.role').isIn(['user','assistant']),
  body('history.*.content').isString().isLength({min:1,max:8000}),
  validateRequest, ctrl.chat);
router.post('/feedback', body('kind').isIn(['venue','vendor']), body('item_id').isInt({min:1}), body('helpful').isBoolean({strict:true}), validateRequest, async(req,res,next)=>{try{
  const {sequelize}=require('../config/database');
  if(!req.user.company_id)throw new (require('../utils/AppError'))('Company required.',403);
  const table=req.body.kind==='venue'?'venues':'vendors';
  if(ctrl.isStaff(req.user))await require('../middleware/access.middleware').own(table,req.body.item_id,req.user.company_id,true);
  else {
    const [item]=await sequelize.query(`SELECT id FROM ${table} WHERE id=? AND company_id IS NULL`,{replacements:[req.body.item_id],type:sequelize.QueryTypes.SELECT});
    if(!item)throw new (require('../utils/AppError'))('Resource not found.',404);
  }
  await sequelize.query('INSERT INTO recommendation_feedback (company_id,user_id,item_kind,item_id,helpful) VALUES (?,?,?,?,?)',{replacements:[req.user.company_id,req.user.id,req.body.kind,req.body.item_id,req.body.helpful?1:0]});
  res.status(201).json({success:true,message:'Feedback saved.'});
 }catch(e){next(e);}});
module.exports = router;
