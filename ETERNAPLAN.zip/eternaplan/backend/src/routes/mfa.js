const router=require('express').Router({caseSensitive:true,strict:true});
const bcrypt=require('bcryptjs');
const {body}=require('express-validator');
const {authenticate}=require('../middleware/auth.middleware');
const {validateRequest}=require('../middleware/validate.middleware');
const {sequelize}=require('../config/database');
const {seal,open}=require('../utils/crypto');
const totp=require('../utils/totp');
const AppError=require('../utils/AppError');
const password=body('password').isString().bail().isLength({min:1,max:128}).bail().custom(v=>Buffer.byteLength(v)<=72);
const code=body('code').isString().bail().matches(/^\d{6}$/);
router.use(authenticate);
const select=(sql,replacements,transaction)=>sequelize.query(sql,{replacements,transaction,type:sequelize.QueryTypes.SELECT});
const encrypted=value=>typeof value==='string'?JSON.parse(value):value;
async function freshUser(req,t){
 const [u]=await select('SELECT *,mfa_pending_expires_at>NOW() AS pending_valid FROM users WHERE id=? FOR UPDATE',[req.user.id],t);
 if(!u||u.status!=='active'||Number(u.token_version)!==Number(req.user.token_version))throw new AppError('Session expired. Sign in again.',401);
 if(!await bcrypt.compare(req.body.password,u.password_hash))throw new AppError('Current password verification failed.',403);
 return u;
}
router.get('/',async(req,res,next)=>{try{
 const [u]=await select('SELECT mfa_secret FROM users WHERE id=?',[req.user.id]);res.json({success:true,data:{enabled:!!u.mfa_secret}});
}catch(e){next(e);}});
router.post('/setup',password,validateRequest,async(req,res,next)=>{try{
 const data=await sequelize.transaction(async t=>{
  const u=await freshUser(req,t);
  if(u.mfa_secret)throw new AppError('Verify and disable the existing authenticator before enrolling a replacement.',409);
  const secret=totp.generate();
  await sequelize.query('UPDATE users SET mfa_pending=?,mfa_pending_expires_at=DATE_ADD(NOW(),INTERVAL 10 MINUTE),mfa_pending_version=token_version WHERE id=?',{replacements:[JSON.stringify(seal(Buffer.from(secret))),u.id],transaction:t});
  return {secret,uri:`otpauth://totp/EternaPlaan:${encodeURIComponent(req.user.email)}?secret=${secret}&issuer=EternaPlaan`,expires_in_seconds:600};
 });res.json({success:true,data});
}catch(e){next(e);}});
for(const action of ['enable','disable'])router.post('/'+action,[password,code],validateRequest,async(req,res,next)=>{try{
 await sequelize.transaction(async t=>{
  const u=await freshUser(req,t);
  if(action==='enable'&&u.mfa_secret)throw new AppError('An authenticator is already enabled. Verify and disable it before replacing it.',409);
  if(action==='enable'&&(!Number(u.pending_valid)||Number(u.mfa_pending_version)!==Number(u.token_version)))throw new AppError('Enrollment expired. Start authenticator setup again.',400);
  const sealed=action==='enable'?u.mfa_pending:u.mfa_secret;
  if(!sealed)throw new AppError('Authenticator is not configured for this action.',409);
  const secret=open(encrypted(sealed)).toString(),step=totp.verify(secret,req.body.code,action==='disable'?Number(u.mfa_last_step):0);
  if(!step)throw new AppError('Invalid or reused authenticator code.',403);
  await sequelize.query('UPDATE users SET mfa_secret=?,mfa_pending=NULL,mfa_pending_expires_at=NULL,mfa_pending_version=NULL,mfa_last_step=?,token_version=token_version+1,refresh_token=NULL WHERE id=?',{replacements:[action==='enable'?JSON.stringify(encrypted(sealed)):null,step,u.id],transaction:t});
  await sequelize.query('INSERT INTO audit_logs (user_id,company_id,action,entity_type,entity_id) VALUES (?,?,?,?,?)',{replacements:[u.id,u.company_id,`mfa_${action}`,'user',u.id],transaction:t});
 });res.json({success:true,message:'Authenticator updated. Sign in again.'});
}catch(e){next(e);}});
module.exports=router;
