/**
 * EternaPlaan - Main Router
 * Wires all route modules to /api/v1/*
 */
const router = require('express').Router({caseSensitive:true,strict:true});
const { authenticate, authorize } = require('../middleware/auth.middleware');
const authCtrl = require('../controllers/authController');
const evtCtrl  = require('../controllers/eventController');
const dashCtrl = require('../controllers/dashboardController');
const { customers, vendors, bookings, guests, finance } = require('../controllers/combinedControllers');
const { body, query, param } = require('express-validator');
const { validateRequest } = require('../middleware/validate.middleware');
const {resource,task}=require('../middleware/resource.middleware');
const staff=authorize('super_admin','admin','event_manager');
const admins=authorize('super_admin','admin');

router.use('/ai', require('./ai'));

// ─── Auth Routes ─────────────────────────────────────────────
router.post('/auth/register',
  [body('email').isEmail(), body('password').isString().isLength({min:12,max:128}).custom(v=>Buffer.byteLength(v)<=72), body('first_name').notEmpty(), body('last_name').notEmpty(), body('phone').notEmpty()],
  validateRequest, authCtrl.register
);
router.post('/auth/resend-otp', [body('email').isEmail()], validateRequest, authCtrl.resendOTP);
router.post('/auth/login',
  [body('email').isEmail(), body('password').isString().bail().isLength({min:1,max:128}).bail().custom(v=>Buffer.byteLength(v)<=72)],
  validateRequest, authCtrl.login
);
router.post('/auth/verify-otp',   [body('email').isEmail(), body('otp').isLength({min:6,max:6})], validateRequest, authCtrl.verifyOTP);
router.post('/auth/refresh',      authCtrl.refreshToken);
router.post('/auth/forgot-password', [body('email').isEmail()], validateRequest, authCtrl.forgotPassword);
router.post('/auth/reset-password',  [body('token').notEmpty(), body('password').isString().isLength({min:12,max:128}).custom(v=>Buffer.byteLength(v)<=72)], validateRequest, authCtrl.resetPassword);
router.post('/auth/logout',       authenticate, authCtrl.logout);
router.get('/auth/me',            authenticate, authCtrl.getProfile);

// Opaque invitation links expose only RSVP fields; all other workspace routes require staff.
const privateLink=(req,res,next)=>{res.set({'Cache-Control':'no-store','Referrer-Policy':'no-referrer'});next();};
router.patch('/guests/rsvp/:code', privateLink, [body('rsvp_status').isIn(['attending','not_attending','maybe','pending']),body('meal_preference').optional().isIn(['veg','non_veg','vegan','jain','no_preference'])], validateRequest, guests.updateRSVP);
router.get('/guests/rsvp-info/:code', privateLink, guests.getRSVPInfo);
router.use('/mfa', require('./mfa'));
router.use('/team', require('./team'));
router.use('/portal', require('./portal'));
router.use(authenticate, require('../middleware/access.middleware').staffAccess);
router.use(require('../middleware/input.middleware').common);
router.use('/documents', require('./documents'));
router.use('/billing', require('./billing'));
router.use(require('./workspace'));

// ─── Dashboard Routes ─────────────────────────────────────────
router.get('/dashboard/overview',          authenticate, authorize('super_admin','admin','event_manager'), dashCtrl.getOverview);
router.get('/dashboard/reports/monthly',   authenticate, authorize('super_admin','admin'), dashCtrl.getMonthlyReport);
router.get('/dashboard/calendar',          authenticate, dashCtrl.getCalendar);

// ─── Event Routes ─────────────────────────────────────────────
router.get('/events',                  authenticate, evtCtrl.getEvents);
router.post('/events',                 authenticate, staff, authorize('super_admin','admin','event_manager'), require('../middleware/input.middleware').required('event_name','customer_id','event_date'), evtCtrl.createEvent);
router.get('/events/upcoming',         authenticate, evtCtrl.getUpcomingEvents);
router.get('/events/:id',              authenticate, resource('events'), evtCtrl.getEvent);
router.put('/events/:id',              authenticate, staff, resource('events'), authorize('super_admin','admin','event_manager'), body('status').optional().isIn(['inquiry','planning','confirmed','in_progress','completed','cancelled','postponed']), validateRequest, evtCtrl.updateEvent);
router.delete('/events/:id',           authenticate, admins, resource('events'), authorize('super_admin','admin'), evtCtrl.deleteEvent);
router.post('/events/:id/tasks', authenticate, staff, resource('events'), require('../middleware/input.middleware').required('title'), evtCtrl.createTask);
router.patch('/events/:id/tasks/:taskId', authenticate, staff, resource('events'), task, body('status').optional().isIn(['pending','in_progress','completed','cancelled']), validateRequest, evtCtrl.updateTask);

// ─── Customer Routes ──────────────────────────────────────────
router.get('/customers',               authenticate, customers.list);
router.post('/customers',              authenticate, staff, authorize('super_admin','admin','event_manager'), require('../middleware/input.middleware').required('first_name','last_name','phone'), customers.create);
router.get('/customers/:id',           authenticate, resource('customers'), customers.get);
router.put('/customers/:id',           authenticate, staff, resource('customers'), authorize('super_admin','admin','event_manager'), customers.update);
router.post('/customers/:id/notes',    authenticate, staff, resource('customers'), require('../middleware/input.middleware').required('note'), customers.addNote);

// ─── Vendor Routes ────────────────────────────────────────────
router.get('/vendors',                 authenticate, vendors.list);
router.get('/vendors/:id',             authenticate, resource('vendors',{sharedRead:true}), vendors.get);
router.patch('/vendors/:id/approve',   authenticate, admins, resource('vendors'), body('approval_status').isIn(['pending','approved','rejected','suspended']), validateRequest, vendors.approve);

// ─── Booking Routes ───────────────────────────────────────────
router.get('/bookings',                authenticate, bookings.list);
router.post('/bookings',               authenticate, staff, authorize('super_admin','admin','event_manager'), require('../middleware/input.middleware').required('event_id','booking_date','booking_type'), bookings.create);
router.patch('/bookings/:id/status',   authenticate, staff, resource('bookings'), body('status').isIn(['pending','confirmed','in_progress','completed','cancelled','no_show']), validateRequest, bookings.updateStatus);

// ─── Guest Routes ─────────────────────────────────────────────
router.get('/guests',                  authenticate, guests.list);
router.post('/guests',                 authenticate, staff, require('../middleware/input.middleware').required('event_id','first_name'), guests.create);
router.post('/guests/bulk-import',     authenticate, staff, body('guests').isArray({min:1,max:500}), body('guests.*.first_name').isString().trim().isLength({min:1,max:100}), validateRequest, guests.bulkImport);

router.patch('/guests/:id/check-in',   authenticate, staff, resource('guests'), guests.checkIn);

// ─── Finance Routes ───────────────────────────────────────────
router.get('/finance/invoices',        authenticate, finance.invoices);
router.get('/finance/invoices/:id',    authenticate, resource('invoices'), finance.getInvoice);
router.post('/finance/payments', authenticate, admins, [
  body('invoice_id').isInt({min:1}),body('request_key').isString().matches(/^[a-zA-Z0-9_-]{16,100}$/),
  body('payment_method').optional().isIn(['cash','upi','bank_transfer','cheque','card','online','other']),
  body('payment_date').optional().isString().matches(/^\d{4}-\d{2}-\d{2}$/).isISO8601({strict:true}),
  body('payment_ref').optional({values:'null'}).isString().isLength({max:200}),
  body('payment_type').optional().isIn(['advance','installment','full','partial'])
],validateRequest,finance.recordPayment);
router.get('/finance/expenses',        authenticate, finance.expenses);
router.post('/finance/expenses',       authenticate, admins, require('../middleware/input.middleware').required('description','category','amount','expense_date'), finance.addExpense);

// Tenant-scoped metadata; propagate database errors through Express.
const meta = (sql,reps) => async(req,res,next)=>{try{
 const {sequelize}=require('../config/database');const rows=await sequelize.query(sql,{replacements:reps?reps(req):[],type:sequelize.QueryTypes.SELECT});res.json({success:true,data:rows});
}catch(e){next(e);}};
router.get('/meta/categories',meta('SELECT id,name FROM event_categories WHERE is_active=1 AND (company_id=? OR company_id IS NULL) ORDER BY sort_order',r=>[r.user.company_id]));
router.get('/meta/vendor-categories',meta('SELECT id,name FROM vendor_categories WHERE is_active=1 ORDER BY name'));
router.get('/meta/venues',meta('SELECT id,name,city,capacity_max,base_price,price_per_day FROM venues WHERE is_available=1 AND (company_id=? OR company_id IS NULL) ORDER BY name',r=>[r.user.company_id]));

// Extra routes to append
router.post('/vendors',                authenticate, admins, authorize('super_admin','admin'), vendors.create);
router.put('/vendors/:id',             authenticate, admins, resource('vendors',{sharedRead:true}), authorize('super_admin','admin'), vendors.update);
router.delete('/vendors/:id',          authenticate, admins, resource('vendors',{sharedRead:true}), authorize('super_admin','admin'), vendors.delete);
router.post('/finance/invoices',       authenticate, admins, authorize('super_admin','admin'), finance.createInvoice);
router.delete('/finance/expenses/:id', authenticate, admins, resource('expenses'), finance.deleteExpense);

router.patch('/guests/:id',            authenticate, staff, resource('guests'), guests.update);
router.delete('/customers/:id',        authenticate, admins, resource('customers'), authorize('super_admin','admin'), customers.delete);

module.exports = router;
