const router=require('express').Router({caseSensitive:true,strict:true}),bcrypt=require('bcryptjs'),crypto=require('crypto');
const {authenticate,authorize}=require('../middleware/auth.middleware');
const {sequelize}=require('../config/database');
const {hash}=require('../utils/crypto');const {enqueue}=require('../services/notifications');const {own}=require('../middleware/access.middleware');
const {body}=require('express-validator');const {validateRequest}=require('../middleware/validate.middleware');
const AppError=require('../utils/AppError');
router.post('/accept',[body('token').isHexadecimal().isLength({min:64,max:64}),body('password').isString().isLength({min:12,max:128}).custom(v=>Buffer.byteLength(v)<=72),body('first_name').trim().isLength({min:1,max:100}),body('last_name').trim().isLength({min:1,max:100})],validateRequest,async(req,res,next)=>{
 try{const password=await bcrypt.hash(req.body.password,12);await sequelize.transaction(async t=>{
  const [i]=await sequelize.query('SELECT * FROM staff_invitations WHERE token_hash=? AND expires_at>NOW() AND accepted_at IS NULL FOR UPDATE',{replacements:[hash(req.body.token)],transaction:t,type:sequelize.QueryTypes.SELECT});if(!i)throw new AppError('Invitation expired or already used.',400);
  const [userId]=await sequelize.query("INSERT INTO users (company_id,role_id,first_name,last_name,email,password_hash,email_verified,status,customer_id) SELECT ?,id,?,?,?,?,1,'active',? FROM roles WHERE name=?",{replacements:[i.company_id,req.body.first_name,req.body.last_name,i.email,password,i.customer_id,i.role_name],type:sequelize.QueryTypes.INSERT,transaction:t});
  if(i.vendor_id)await sequelize.query('UPDATE vendors SET user_id=? WHERE id=? AND company_id=?',{replacements:[userId,i.vendor_id,i.company_id],transaction:t});
  await sequelize.query('UPDATE staff_invitations SET accepted_at=NOW() WHERE id=?',{replacements:[i.id],transaction:t});
 });res.status(201).json({success:true,message:'Invitation accepted. Sign in to continue.'});}catch(e){next(e);}
});
router.use(authenticate,authorize('admin','super_admin'));
router.post('/invitations',[body('email').isEmail(),body('role').isIn(['event_manager','customer','vendor']),body('customer_id').optional().isInt({min:1}),body('vendor_id').optional().isInt({min:1})],validateRequest,async(req,res,next)=>{
 try{if(!req.user.company_id)throw new AppError('Company required.',403);
 const {email,role,customer_id,vendor_id}=req.body;
 if(role==='customer'&&!customer_id||role==='vendor'&&!vendor_id)throw new AppError('Select the matching customer/vendor record.',422);
 if(role==='customer')await own('customers',customer_id,req.user.company_id);if(role==='vendor')await own('vendors',vendor_id,req.user.company_id);
 const token=crypto.randomBytes(32).toString('hex');await sequelize.transaction(async t=>{
 await sequelize.query('INSERT INTO staff_invitations (id,company_id,email,role_name,token_hash,expires_at,customer_id,vendor_id) VALUES (?,?,?,?,?,DATE_ADD(NOW(),INTERVAL 48 HOUR),?,?)',{replacements:[crypto.randomUUID(),req.user.company_id,email,role,hash(token),role==='customer'?customer_id:null,role==='vendor'?vendor_id:null],transaction:t});
 await enqueue('email',{to:email,subject:'Your EternaPlaan invitation',html:`Accept your invitation: ${process.env.FRONTEND_URL}/accept-invitation?token=${token}`},t);
 });res.status(201).json({success:true,message:'Invitation queued for delivery.'});}catch(e){next(e);}
});
module.exports=router;
