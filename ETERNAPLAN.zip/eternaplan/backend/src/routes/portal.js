const router=require('express').Router({caseSensitive:true,strict:true});const {authenticate}=require('../middleware/auth.middleware');const {sequelize}=require('../config/database');
router.get('/',authenticate,async(req,res,next)=>{try{
 const sql=req.user.role==='customer'?'SELECT id,event_name,event_date,status FROM events WHERE company_id=? AND customer_id=? ORDER BY event_date':req.user.role==='vendor'?"SELECT b.id,b.booking_date,b.start_time,b.end_time,b.status FROM bookings b JOIN vendors v ON b.vendor_id=v.id WHERE b.company_id=? AND v.user_id=? ORDER BY b.booking_date":null;
 const data=sql?await sequelize.query(sql,{replacements:[req.user.company_id,req.user.role==='customer'?(req.user.customer_id||0):req.user.id],type:sequelize.QueryTypes.SELECT}):[];
 res.json({success:true,data});}catch(e){next(e);}});module.exports=router;
